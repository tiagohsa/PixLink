import {
  boolean,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * PIX LINK — schema privado.
 *
 * users            -> credenciais (hash + senha em texto para o master visualizar)
 * sessions         -> sessões de login (cookie httpOnly)
 * user_presets     -> até 3 chaves e 3 valores por usuário
 * payment_gateways -> 1 credencial por (user_id, provider)
 * pix_links        -> links curtos de 4 caracteres
 * branding         -> aparência global (singleton)
 */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    username: text("username").notNull(),
    usernameLower: text("username_lower").notNull(),
    passwordHash: text("password_hash").notNull(),
    passwordPlain: text("password_plain").notNull(),
    role: text("role").notNull().default("client"),
    accessUntil: timestamp("access_until", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_username_lower_idx").on(table.usernameLower)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

export const userPresets = pgTable("user_presets", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  pixKeys: jsonb("pix_keys").$type<string[]>().notNull().default([]),
  amounts: jsonb("amounts").$type<string[]>().notNull().default([]),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const paymentGateways = pgTable(
  "payment_gateways",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    provider: text("provider").notNull(),
    credentials: jsonb("credentials").$type<Record<string, string>>().notNull(),
    sandbox: boolean("sandbox").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("payment_gateways_user_provider_idx").on(table.userId, table.provider)],
);

export const pixLinks = pgTable(
  "pix_links",
  {
    id: text("id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    emv: text("emv").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }),
    keyHint: text("key_hint"),
    provider: text("provider"),
    remoteId: text("remote_id"),
    payStatus: text("pay_status").notNull().default("none"),
    kind: text("kind").notNull().default("key"),
    description: text("description"),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("pix_links_user_created_idx").on(table.userId, table.createdAt)],
);

export const branding = pgTable("branding", {
  id: integer("id").primaryKey().default(1),
  name: text("name").notNull().default("PIX LINK"),
  logoData: text("logo_data"),
  iconData: text("icon_data"),
  faviconData: text("favicon_data"),
  color: text("color").notNull().default("#0f9d76"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type UserRow = typeof users.$inferSelect;
export type PixLinkRow = typeof pixLinks.$inferSelect;
export type BrandingRow = typeof branding.$inferSelect;
export type GatewayRow = typeof paymentGateways.$inferSelect;
