import { eq } from "drizzle-orm";
import { db } from "@/db";
import { branding } from "@/db/schema";

export type Branding = {
  name: string;
  logoData: string | null;
  iconData: string | null;
  faviconData: string | null;
  color: string;
};

export const DEFAULT_BRANDING: Branding = {
  name: "PIX LINK",
  logoData: null,
  iconData: null,
  faviconData: null,
  color: "#0f9d76",
};

export const BRAND_COLORS = [
  "#0f9d76",
  "#2563eb",
  "#7c3aed",
  "#db2777",
  "#ea580c",
  "#0f766e",
  "#111827",
  "#0891b2",
];

export function isHexColor(value: string | null | undefined): boolean {
  return typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value.trim());
}

export async function getBranding(): Promise<Branding> {
  try {
    const rows = await db.select().from(branding).where(eq(branding.id, 1)).limit(1);
    const row = rows[0];
    if (!row) return DEFAULT_BRANDING;
    return {
      name: row.name?.trim() || DEFAULT_BRANDING.name,
      logoData: row.logoData ?? null,
      iconData: row.iconData ?? null,
      faviconData: row.faviconData ?? null,
      color: isHexColor(row.color) ? row.color : DEFAULT_BRANDING.color,
    };
  } catch {
    return DEFAULT_BRANDING;
  }
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace("#", "");
  return [
    parseInt(clean.slice(0, 2), 16) || 15,
    parseInt(clean.slice(2, 4), 16) || 157,
    parseInt(clean.slice(4, 6), 16) || 118,
  ];
}

export function mixWithWhite(hex: string, weight: number): string {
  const [r, g, b] = hexToRgb(hex);
  const w = Math.min(1, Math.max(0, weight));
  const mix = (channel: number) => Math.round(channel + (255 - channel) * w);
  return `#${[mix(r), mix(g), mix(b)].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}

export function darken(hex: string, weight = 0.18): string {
  const [r, g, b] = hexToRgb(hex);
  const f = 1 - Math.min(1, Math.max(0, weight));
  return `#${[r, g, b]
    .map((c) => Math.max(0, Math.round(c * f)).toString(16).padStart(2, "0"))
    .join("")}`;
}

export function readableOn(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.65 ? "#0b1220" : "#ffffff";
}

export type BrandVars = Record<string, string>;

export function brandVars(color: string): BrandVars {
  const safe = isHexColor(color) ? color : DEFAULT_BRANDING.color;
  return {
    "--brand": safe,
    "--brand-dark": darken(safe, 0.16),
    "--brand-soft": mixWithWhite(safe, 0.88),
    "--brand-soft-2": mixWithWhite(safe, 0.94),
    "--brand-ring": mixWithWhite(safe, 0.55),
    "--brand-contrast": readableOn(safe),
  };
}

export function brandStyle(color: string): React.CSSProperties {
  return brandVars(color) as unknown as React.CSSProperties;
}
