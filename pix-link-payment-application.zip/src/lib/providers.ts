/* ------------------------------------------------------------------
 * Integrações de pagamento — cada usuário usa as SUAS credenciais.
 * As chamadas são server-side; os erros do provedor são repassados
 * em português para a interface.
 * ------------------------------------------------------------------ */

export type ProviderId = "asaas" | "mercadopago" | "bspay" | "pixup";
export type PayStatus = "pending" | "paid";

export type ProviderField = {
  key: string;
  label: string;
  type: "text" | "password";
  placeholder: string;
  optional?: boolean;
};

export const PROVIDERS: Array<{
  id: ProviderId;
  name: string;
  description: string;
  hasSandbox: boolean;
  fields: ProviderField[];
  color: string;
  hint: string;
}> = [
  {
    id: "asaas",
    name: "Asaas",
    description: "Cobranças Pix com confirmação automática.",
    hasSandbox: true,
    color: "#0b5cff",
    hint: "Painel Asaas → Integrações → Chave de API.",
    fields: [
      { key: "apiKey", label: "API key (access_token)", type: "password", placeholder: "$aact_..." },
      { key: "customerId", label: "ID do cliente (opcional)", type: "text", placeholder: "cus_000...", optional: true },
    ],
  },
  {
    id: "mercadopago",
    name: "Mercado Pago",
    description: "Pix pelo Mercado Pago com status em tempo real.",
    hasSandbox: false,
    color: "#00a1e0",
    hint: "Suas aplicações → Credenciais → Access Token (APP_USR-).",
    fields: [
      { key: "accessToken", label: "Access Token", type: "password", placeholder: "APP_USR-..." },
    ],
  },
  {
    id: "bspay",
    name: "BSPay",
    description: "Cash-in Pix via BSPay.",
    hasSandbox: false,
    color: "#111827",
    hint: "BSPay → API → gerar token Bearer.",
    fields: [
      { key: "apiKey", label: "Bearer API key", type: "password", placeholder: "seu_token" },
    ],
  },
  {
    id: "pixup",
    name: "PixUp",
    description: "QR Code Pix dinâmico da PixUp.",
    hasSandbox: false,
    color: "#7c3aed",
    hint: "PixUp → Credenciais da API.",
    fields: [
      { key: "clientId", label: "Client ID", type: "text", placeholder: "client_id" },
      { key: "clientSecret", label: "Client Secret", type: "password", placeholder: "client_secret" },
    ],
  },
];

export function providerLabel(provider: string | null | undefined): string {
  return PROVIDERS.find((item) => item.id === provider)?.name ?? "Manual";
}

export type ChargeInput = {
  amount: number;
  description: string;
  externalId: string;
  webhookBase: string;
};

export type ChargeResult = { remoteId: string; emv: string };

export type ProviderOutcome = { ok: true; data: ChargeResult } | { ok: false; error: string };

async function httpJson(
  url: string,
  init: RequestInit & { timeoutMs?: number } = {},
): Promise<{ ok: boolean; status: number; json: Record<string, unknown> | null; text: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeoutMs ?? 22_000);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal, cache: "no-store" });
    const text = await response.text();
    let json: Record<string, unknown> | null = null;
    try {
      json = JSON.parse(text) as Record<string, unknown>;
    } catch {
      json = null;
    }
    return { ok: response.ok, status: response.status, json, text };
  } catch (error) {
    const aborted = error instanceof Error && error.name === "AbortError";
    return {
      ok: false,
      status: 0,
      json: null,
      text: aborted ? "Tempo esgotado ao falar com o provedor." : "Não foi possível conectar ao provedor.",
    };
  } finally {
    clearTimeout(timer);
  }
}

function errorMessage(payload: { json?: Record<string, unknown> | null; text?: string }, fallback: string): string {
  const json = payload.json;
  if (json) {
    const candidates = [json.message, json.error, json.error_description, json.detail, json.title];
    const first = candidates.find((value) => typeof value === "string" && value.trim());
    if (typeof first === "string") return first;
    if (Array.isArray(json.errors) && json.errors.length > 0) {
      const item = json.errors[0] as Record<string, unknown>;
      if (item && typeof item.description === "string") return item.description;
    }
  }
  if (payload.text && payload.text.length < 220 && !payload.text.trim().startsWith("<")) return payload.text;
  return fallback;
}

/** Procura recursivamente por um payload Pix (EMV começa em 000201). */
export function findPixPayload(value: unknown, depth = 0): string | null {
  if (depth > 6 || value === null || value === undefined) return null;
  if (typeof value === "string") {
    const trimmed = value.trim();
    return /^000201/.test(trimmed) && trimmed.length > 40 ? trimmed : null;
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findPixPayload(item, depth + 1);
      if (found) return found;
    }
    return null;
  }
  if (typeof value === "object") {
    const keys = Object.keys(value as Record<string, unknown>);
    const preferred = keys.filter((key) => /pix|qrcode|qr_code|emv|payload|copy|brcode|br_code|encoded/i.test(key));
    for (const key of [...preferred, ...keys]) {
      const found = findPixPayload((value as Record<string, unknown>)[key], depth + 1);
      if (found) return found;
    }
  }
  return null;
}

function pickId(json: Record<string, unknown> | null, extra: string[] = []): string {
  if (!json) return "";
  const keys = ["id", "transaction_id", "transactionId", "external_id", "externalId", "payment_id", ...extra];
  for (const key of keys) {
    const value = json[key];
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  for (const nested of ["data", "transaction", "charge", "payment"]) {
    const child = json[nested];
    if (child && typeof child === "object") {
      const found = pickId(child as Record<string, unknown>, extra);
      if (found) return found;
    }
  }
  return "";
}

function statusIsPaid(json: Record<string, unknown> | null): boolean {
  if (!json) return false;
  const text = JSON.stringify(json).toLowerCase();
  const direct = String(json.status ?? json.payment_status ?? json.situation ?? "").toLowerCase();
  return (
    /^(paid|approved|confirmed|received|completed|succeeded|pago|concluida|concluído|received_in_cash)$/.test(direct) ||
    /"status"\s*:\s*"(paid|approved|confirmed|received|completed|succeeded|pago)"/.test(text)
  );
}



/* ------------------------------ Asaas ------------------------------ */

async function createAsaasCharge(
  credentials: Record<string, string>,
  sandbox: boolean,
  input: ChargeInput,
): Promise<ProviderOutcome> {
  const base = sandbox ? "https://api-sandbox.asaas.com/v3" : "https://api.asaas.com/v3";
  const headers = {
    "content-type": "application/json",
    access_token: credentials.apiKey ?? "",
    "User-Agent": "PixLink/1.0",
  };
  let customerId = (credentials.customerId ?? "").trim();

  if (!customerId) {
    const customer = await httpJson(`${base}/customers`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        name: "Cliente Pix Link",
        email: `pixlink+${Date.now()}@pagamento.local`,
        externalReference: input.externalId,
        notificationDisabled: true,
      }),
    });
    if (!customer.ok) {
      return {
        ok: false,
        error: `Asaas recusou a criação do cliente: ${errorMessage(customer, "verifique a API key e o modo sandbox.")}`,
      };
    }
    customerId = pickId(customer.json);
    if (!customerId) return { ok: false, error: "Asaas não retornou o cliente da cobrança." };
  }

  const due = new Date(Date.now() + 86_400_000).toISOString().slice(0, 10);
  const payment = await httpJson(`${base}/payments`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      customer: customerId,
      billingType: "PIX",
      value: Number(input.amount.toFixed(2)),
      dueDate: due,
      description: input.description.slice(0, 120),
      externalReference: input.externalId,
    }),
  });
  if (!payment.ok) {
    return { ok: false, error: `Asaas: ${errorMessage(payment, "não foi possível criar a cobrança.")}` };
  }
  const paymentId = pickId(payment.json);
  if (!paymentId) return { ok: false, error: "Asaas não retornou o identificador da cobrança." };

  const qr = await httpJson(`${base}/payments/${encodeURIComponent(paymentId)}/pixQrCode`, { headers });
  let emv = qr.ok ? findPixPayload(qr.json) : null;
  if (!emv && qr.ok && typeof qr.json?.payload === "string") emv = qr.json.payload;
  if (!emv) {
    return {
      ok: false,
      error: `Asaas: cobrança criada, mas sem QR Pix. ${errorMessage(qr, "Tente novamente.")}`,
    };
  }
  return { ok: true, data: { remoteId: paymentId, emv } };
}

async function checkAsaas(credentials: Record<string, string>, sandbox: boolean, remoteId: string) {
  const base = sandbox ? "https://api-sandbox.asaas.com/v3" : "https://api.asaas.com/v3";
  const response = await httpJson(`${base}/payments/${encodeURIComponent(remoteId)}`, {
    headers: { access_token: credentials.apiKey ?? "", "User-Agent": "PixLink/1.0" },
  });
  return response.ok && statusIsPaid(response.json);
}

/* --------------------------- Mercado Pago --------------------------- */

async function createMercadoPagoCharge(
  credentials: Record<string, string>,
  _sandbox: boolean,
  input: ChargeInput,
): Promise<ProviderOutcome> {
  const response = await httpJson("https://api.mercadopago.com/v1/payments", {
    method: "POST",
    headers: {
      authorization: `Bearer ${credentials.accessToken ?? ""}`,
      "content-type": "application/json",
      "X-Idempotency-Key": input.externalId,
    },
    body: JSON.stringify({
      transaction_amount: Number(input.amount.toFixed(2)),
      description: input.description.slice(0, 120),
      payment_method_id: "pix",
      external_reference: input.externalId,
      notification_url: input.webhookBase ? `${input.webhookBase}/api/hooks/mercadopago` : undefined,
      payer: { email: `pagador+${input.externalId}@pixlink.app`, first_name: "Cliente", last_name: "Pix" },
    }),
  });
  if (!response.ok) {
    return { ok: false, error: `Mercado Pago: ${errorMessage(response, "não foi possível criar o pagamento.")}` };
  }
  const remoteId = pickId(response.json);
  const emv = findPixPayload(response.json);
  if (!remoteId || !emv) {
    return { ok: false, error: "Mercado Pago não retornou o QR Code Pix da cobrança." };
  }
  return { ok: true, data: { remoteId, emv } };
}

async function checkMercadoPago(credentials: Record<string, string>, _sandbox: boolean, remoteId: string) {
  const response = await httpJson(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(remoteId)}`, {
    headers: { authorization: `Bearer ${credentials.accessToken ?? ""}` },
  });
  return response.ok && statusIsPaid(response.json);
}

/* ------------------------------ BSPay ------------------------------ */

async function createBspayCharge(
  credentials: Record<string, string>,
  _sandbox: boolean,
  input: ChargeInput,
): Promise<ProviderOutcome> {
  const response = await httpJson("https://api.bspay.co/v2/transactions/cashin", {
    method: "POST",
    headers: {
      authorization: `Bearer ${credentials.apiKey ?? ""}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      amount: Number(input.amount.toFixed(2)),
      currency: "BRL",
      external_id: input.externalId,
      description: input.description.slice(0, 120),
      postback_url: input.webhookBase ? `${input.webhookBase}/api/hooks/bspay` : undefined,
    }),
  });
  if (!response.ok) {
    return { ok: false, error: `BSPay: ${errorMessage(response, "não foi possível criar a cobrança.")}` };
  }
  const emv = findPixPayload(response.json);
  const remoteId = pickId(response.json);
  if (!emv || !remoteId) {
    return { ok: false, error: "BSPay não retornou o código Pix da cobrança." };
  }
  return { ok: true, data: { remoteId, emv } };
}

async function checkBspay(credentials: Record<string, string>, _sandbox: boolean, remoteId: string) {
  const response = await httpJson(`https://api.bspay.co/v2/transactions/${encodeURIComponent(remoteId)}`, {
    headers: { authorization: `Bearer ${credentials.apiKey ?? ""}` },
  });
  return response.ok && statusIsPaid(response.json);
}

/* ------------------------------ PixUp ------------------------------ */

async function pixupToken(credentials: Record<string, string>): Promise<string | null> {
  const body = {
    clientId: credentials.clientId ?? "",
    clientSecret: credentials.clientSecret ?? "",
    grant_type: "client_credentials",
  };
  const attempts: Array<{ url: string; init: RequestInit }> = [
    {
      url: "https://api.pixupbr.com/v2/oauth/token",
      init: { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) },
    },
    {
      url: "https://api.pixupbr.com/v2/auth/token",
      init: { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) },
    },
    {
      url: "https://api.pixupbr.com/v2/oauth/token",
      init: {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "client_credentials",
          client_id: credentials.clientId ?? "",
          client_secret: credentials.clientSecret ?? "",
        }).toString(),
      },
    },
  ];
  for (const attempt of attempts) {
    const response = await httpJson(attempt.url, attempt.init);
    if (response.ok && response.json) {
      const token = response.json.access_token ?? response.json.accessToken ?? response.json.token;
      if (typeof token === "string" && token.length > 8) return token;
    }
  }
  return null;
}

async function createPixupCharge(
  credentials: Record<string, string>,
  _sandbox: boolean,
  input: ChargeInput,
): Promise<ProviderOutcome> {
  const token = await pixupToken(credentials);
  if (!token) {
    return { ok: false, error: "PixUp: não foi possível autenticar. Confira Client ID e Client Secret." };
  }
  const response = await httpJson("https://api.pixupbr.com/v2/pix/qrcode", {
    method: "POST",
    headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
    body: JSON.stringify({
      amount: Number(input.amount.toFixed(2)),
      external_id: input.externalId,
      postbackUrl: input.webhookBase ? `${input.webhookBase}/api/hooks/pixup` : undefined,
    }),
  });
  if (!response.ok) {
    return { ok: false, error: `PixUp: ${errorMessage(response, "não foi possível criar o QR Code.")}` };
  }
  const emv = findPixPayload(response.json);
  const remoteId = pickId(response.json);
  if (!emv || !remoteId) return { ok: false, error: "PixUp não retornou o código Pix da cobrança." };
  return { ok: true, data: { remoteId, emv } };
}

async function checkPixup(credentials: Record<string, string>, _sandbox: boolean, remoteId: string) {
  const token = await pixupToken(credentials);
  if (!token) return false;
  const response = await httpJson(`https://api.pixupbr.com/v2/pix/${encodeURIComponent(remoteId)}`, {
    headers: { authorization: `Bearer ${token}` },
  });
  return response.ok && statusIsPaid(response.json);
}

/* ----------------------------- interface ---------------------------- */

export async function createProviderCharge(
  provider: ProviderId,
  credentials: Record<string, string>,
  sandbox: boolean,
  input: ChargeInput,
): Promise<ProviderOutcome> {
  switch (provider) {
    case "asaas":
      return createAsaasCharge(credentials, sandbox, input);
    case "mercadopago":
      return createMercadoPagoCharge(credentials, sandbox, input);
    case "bspay":
      return createBspayCharge(credentials, sandbox, input);
    case "pixup":
      return createPixupCharge(credentials, sandbox, input);
    default:
      return { ok: false, error: "Provedor não suportado." };
  }
}

export async function checkProviderStatus(
  provider: ProviderId,
  credentials: Record<string, string>,
  sandbox: boolean,
  remoteId: string,
): Promise<boolean> {
  try {
    switch (provider) {
      case "asaas":
        return await checkAsaas(credentials, sandbox, remoteId);
      case "mercadopago":
        return await checkMercadoPago(credentials, sandbox, remoteId);
      case "bspay":
        return await checkBspay(credentials, sandbox, remoteId);
      case "pixup":
        return await checkPixup(credentials, sandbox, remoteId);
      default:
        return false;
    }
  } catch {
    return false;
  }
}

export function isProviderId(value: unknown): value is ProviderId {
  return value === "asaas" || value === "mercadopago" || value === "bspay" || value === "pixup";
}
