import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentGateways, pixLinks, type PixLinkRow } from "@/db/schema";
import {
  extractPixAmountSync,
  maskPixKey,
  summarizePixEmv,
  type PixInspection,
} from "@/lib/pix";
import { checkProviderStatus, isProviderId, type ProviderId } from "@/lib/providers";

export const LINK_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789";

export function randomShortId(): string {
  let id = "";
  for (let i = 0; i < 4; i += 1) {
    id += LINK_ALPHABET[Math.floor(Math.random() * LINK_ALPHABET.length)];
  }
  return id;
}

export type LinkDTO = {
  id: string;
  amount: number | null;
  keyMasked: string;
  keyRaw: string | null;
  provider: string | null;
  providerName: string;
  payStatus: "none" | "pending" | "paid";
  kind: "key" | "copy" | "api";
  description: string | null;
  emv: string;
  expiresAt: string | null;
  createdAt: string;
  expired: boolean;
  summary: string;
};

function toNumber(value: string | number | null): number | null {
  if (value === null) return null;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

export function isExpired(row: Pick<PixLinkRow, "expiresAt">): boolean {
  return row.expiresAt !== null && row.expiresAt.getTime() <= Date.now();
}

function normalizeStatus(value: string): "none" | "pending" | "paid" {
  if (value === "paid") return "paid";
  if (value === "pending") return "pending";
  return "none";
}

function normalizeKind(value: string): "key" | "copy" | "api" {
  if (value === "copy") return "copy";
  if (value === "api") return "api";
  return "key";
}

export function toDto(row: PixLinkRow): LinkDTO {
  return {
    id: row.id,
    amount: toNumber(row.amount) ?? extractPixAmountSync(row.emv),
    keyMasked: row.keyHint ? maskPixKey(row.keyHint) : "Copia e cola",
    keyRaw: row.keyHint,
    provider: row.provider,
    providerName: row.provider ?? "",
    payStatus: normalizeStatus(row.payStatus),
    kind: normalizeKind(row.kind),
    description: row.description,
    emv: row.emv,
    expiresAt: row.expiresAt ? row.expiresAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    expired: isExpired(row),
    summary: summarizePixEmv(row.emv),
  };
}

export async function listLinks(userId: string): Promise<LinkDTO[]> {
  const rows = await db
    .select()
    .from(pixLinks)
    .where(eq(pixLinks.userId, userId))
    .orderBy(desc(pixLinks.createdAt))
    .limit(60);
  return rows.map(toDto);
}

export async function createLink(input: {
  userId: string;
  emv: string;
  amount: number | null;
  keyHint: string | null;
  provider?: string | null;
  remoteId?: string | null;
  payStatus?: string;
  kind: "key" | "copy" | "api";
  description?: string | null;
  expiresAt?: Date | null;
}): Promise<LinkDTO> {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const id = randomShortId();
    try {
      const rows = await db
        .insert(pixLinks)
        .values({
          id,
          userId: input.userId,
          emv: input.emv,
          amount: input.amount === null ? null : input.amount.toFixed(2),
          keyHint: input.keyHint,
          provider: input.provider ?? null,
          remoteId: input.remoteId ?? null,
          payStatus: input.payStatus ?? "none",
          kind: input.kind,
          description: input.description ?? null,
          expiresAt: input.expiresAt ?? null,
        })
        .returning();
      if (rows[0]) return toDto(rows[0]);
    } catch {
      /* colisão de ID de 4 caracteres: tenta novamente */
    }
  }
  throw new Error("Não foi possível reservar um link curto. Tente novamente.");
}

export async function deleteLink(userId: string, id: string): Promise<boolean> {
  const rows = await db
    .delete(pixLinks)
    .where(and(eq(pixLinks.id, id), eq(pixLinks.userId, userId)))
    .returning({ id: pixLinks.id });
  return rows.length > 0;
}

export type PublicLinkView =
  | { state: "notfound" }
  | { state: "expired" }
  | {
      state: "ok";
      id: string;
      amount: number | null;
      emv: string;
      summary: string;
      payStatus: "none" | "pending" | "paid";
      tracked: boolean;
    };

export async function getLinkRow(id: string): Promise<PixLinkRow | null> {
  if (!/^[abcdefghjkmnpqrstuvwxyz23456789]{4}$/.test(id)) return null;
  const rows = await db.select().from(pixLinks).where(eq(pixLinks.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function refreshPaidStatus(row: PixLinkRow): Promise<PixLinkRow> {
  if (!row.provider || row.payStatus === "paid" || !row.remoteId) return row;
  if (!isProviderId(row.provider)) return row;
  const gatewayRows = await db
    .select()
    .from(paymentGateways)
    .where(
      and(
        eq(paymentGateways.userId, row.userId),
        eq(paymentGateways.provider, row.provider),
      ),
    )
    .limit(1);
  const gateway = gatewayRows[0];
  if (!gateway) return row;
  const paid = await checkProviderStatus(
    row.provider as ProviderId,
    gateway.credentials,
    gateway.sandbox,
    row.remoteId,
  );
  if (!paid) return row;
  const updated = await db
    .update(pixLinks)
    .set({ payStatus: "paid" })
    .where(eq(pixLinks.id, row.id))
    .returning();
  return updated[0] ?? { ...row, payStatus: "paid" };
}

export function toPublicView(row: PixLinkRow): PublicLinkView {
  if (isExpired(row)) return { state: "expired" };
  return {
    state: "ok",
    id: row.id,
    amount: toNumber(row.amount) ?? extractPixAmountSync(row.emv),
    emv: row.emv,
    summary: summarizePixEmv(row.emv),
    payStatus: normalizeStatus(row.payStatus),
    tracked: Boolean(row.provider && row.remoteId),
  };
}

export type PixInspectionDto = PixInspection;
