import { deflateSync } from "node:zlib";

/** CRC32 (PNG) */
function crc32(buffer: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buffer.length; i += 1) {
    crc ^= buffer[i];
    for (let j = 0; j < 8; j += 1) {
      crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1;
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type: string, data: Buffer): Buffer {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const typeBuffer = Buffer.from(type, "ascii");
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), 0);
  return Buffer.concat([length, typeBuffer, data, crc]);
}

export function encodePng(size: number, rgba: Buffer): Buffer {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  const raw = Buffer.alloc(size * (size * 4 + 1));
  for (let y = 0; y < size; y += 1) {
    const rowStart = y * (size * 4 + 1);
    raw[rowStart] = 0; // filtro None
    rgba.copy(raw, rowStart + 1, y * size * 4, (y + 1) * size * 4);
  }
  return Buffer.concat([
    signature,
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace("#", "");
  const value = /^[0-9a-f]{6}$/i.test(clean) ? clean : "0f9d76";
  return [
    parseInt(value.slice(0, 2), 16),
    parseInt(value.slice(2, 4), 16),
    parseInt(value.slice(4, 6), 16),
  ];
}

/**
 * Ícone padrão do PWA: fundo mint, losangos no tom da marca (símbolo Pix estilizado).
 */
export function makeBrandIconPng(size: number, color: string): Buffer {
  const [r, g, b] = hexToRgb(color);
  const rgba = Buffer.alloc(size * size * 4);
  const center = size / 2;
  const radius = size * 0.5;
  const glyphHalf = size * 0.27;
  const armWidth = size * 0.115;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const idx = (y * size + x) * 4;
      // fundo: gradiente diagonal suave entre branco e tom claro da marca
      const t = (x + y) / (2 * size);
      let pr = Math.round(255 - (255 - (r + (255 - r) * 0.75)) * (1 - t));
      let pg = Math.round(255 - (255 - (g + (255 - g) * 0.75)) * (1 - t));
      let pb = Math.round(255 - (255 - (b + (255 - b) * 0.75)) * (1 - t));
      let alpha = 255;

      // cantos arredondados
      const dx = Math.abs(x - center + 0.5);
      const dy = Math.abs(y - center + 0.5);
      const cornerRadius = size * 0.22;
      if (dx > radius - cornerRadius && dy > radius - cornerRadius) {
        const cdx = dx - (radius - cornerRadius);
        const cdy = dy - (radius - cornerRadius);
        if (Math.hypot(cdx, cdy) > cornerRadius) alpha = 0;
      }

      // losango central (símbolo pix)
      const diamond = Math.abs(x - center + 0.5) + Math.abs(y - center + 0.5);
      if (diamond <= glyphHalf && diamond >= glyphHalf - armWidth) {
        pr = r;
        pg = g;
        pb = b;
        alpha = 255;
      }
      // dois losangos menores nas extremidades (linhas cruzadas)
      const line = Math.abs(Math.abs(x - center + 0.5) - Math.abs(y - center + 0.5));
      if (diamond < glyphHalf && line < armWidth * 0.42) {
        pr = 255;
        pg = 255;
        pb = 255;
        alpha = 255;
      }

      rgba[idx] = Math.max(0, Math.min(255, pr));
      rgba[idx + 1] = Math.max(0, Math.min(255, pg));
      rgba[idx + 2] = Math.max(0, Math.min(255, pb));
      rgba[idx + 3] = alpha;
    }
  }
  return encodePng(size, rgba);
}

/** Converte data URL em bytes + mime. */
export function dataUrlToBuffer(dataUrl: string): { buffer: Buffer; mime: string } | null {
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl.trim());
  if (!match) return null;
  try {
    return { buffer: Buffer.from(match[2], "base64"), mime: match[1] };
  } catch {
    return null;
  }
}
