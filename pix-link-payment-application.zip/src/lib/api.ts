import { NextResponse } from "next/server";
import { getViewer, type Viewer } from "@/lib/auth";
import { db } from "@/db";
import { paymentGateways } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import type { ProviderId } from "@/lib/providers";

type Guard = { viewer: Viewer; response?: undefined } | { viewer?: undefined; response: NextResponse };

export async function requireViewer(options: { master?: boolean } = {}): Promise<Guard> {
  const viewer = await getViewer();
  if (!viewer) {
    return {
      response: NextResponse.json({ error: "Sessão expirada. Entre novamente." }, { status: 401 }),
    };
  }
  if (viewer.role === "client" && viewer.expired) {
    return {
      response: NextResponse.json(
        { error: "Seu acesso expirou. Fale com o administrador para renovar." },
        { status: 403 },
      ),
    };
  }
  if (options.master && viewer.role !== "master") {
    return {
      response: NextResponse.json({ error: "Acesso restrito ao administrador." }, { status: 403 }),
    };
  }
  return { viewer };
}

export async function getGatewayForUser(userId: string, provider: ProviderId) {
  const rows = await db
    .select()
    .from(paymentGateways)
    .where(and(eq(paymentGateways.userId, userId), eq(paymentGateways.provider, provider)))
    .limit(1);
  return rows[0] ?? null;
}

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function requestOrigin(request: Request): string {
  const url = new URL(request.url);
  const forwardedHost = request.headers.get("x-forwarded-host");
  const forwardedProto = request.headers.get("x-forwarded-proto");
  if (forwardedHost) return `${forwardedProto ?? "https"}://${forwardedHost}`;
  return url.origin;
}
