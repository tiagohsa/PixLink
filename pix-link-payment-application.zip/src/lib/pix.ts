/* ------------------------------------------------------------------
 * PIX LINK — utilitários de BR Code (EMV® QRCPS-MPM)
 * TLV + CRC16-CCITT (0xFFFF / polinômio 0x1021)
 * Puro: pode rodar no servidor e no cliente.
 * ------------------------------------------------------------------ */

export type PixKeyType = "cpf" | "cnpj" | "email" | "phone" | "evp" | "unknown";

export type Tlv = { tag: string; length: number; value: string };

const MAX_EMV_LENGTH = 4096;

export function crc16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i += 1) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j += 1) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

export function sanitizeEmv(raw: string): string {
  return raw.replace(/[\r\n\t]/g, "").replace(/\s{2,}/g, " ").trim().slice(0, MAX_EMV_LENGTH);
}

/** Lê TLVs de um payload. Tolerante a campos extras no fim. */
export function parseTlv(payload: string): Tlv[] {
  const out: Tlv[] = [];
  let i = 0;
  while (i + 4 <= payload.length) {
    const tag = payload.slice(i, i + 2);
    const lenRaw = payload.slice(i + 2, i + 4);
    if (!/^\d{2}$/.test(tag) || !/^\d{2}$/.test(lenRaw)) break;
    const length = Number(lenRaw);
    const value = payload.slice(i + 4, i + 4 + length);
    if (value.length !== length) break;
    out.push({ tag, length, value });
    i += 4 + length;
  }
  return out;
}

export function fieldMap(payload: string): Record<string, string> {
  const map: Record<string, string> = {};
  for (const item of parseTlv(payload)) {
    if (map[item.tag] === undefined) map[item.tag] = item.value;
  }
  return map;
}

export function normalizeAmountInput(raw: string | number | null | undefined): number | null {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === "number") {
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) / 100 : null;
  }
  let text = raw.replace(/[^\d.,-]/g, "").trim();
  if (!text) return null;
  if (text.includes(",")) {
    text = text.replace(/\./g, "").replace(",", ".");
  } else if ((text.match(/\./g) ?? []).length > 1) {
    text = text.replace(/\./g, "");
  }
  const value = Number(text);
  if (!Number.isFinite(value) || value <= 0) return null;
  return Math.round(value * 100) / 100;
}

export function parseEmvAmount(value: string | undefined | null): number | null {
  if (!value) return null;
  const parsed = normalizeAmountInput(value.trim().replace(",", "."));
  return parsed ? Math.min(parsed, 999999999) : null;
}

export function formatBrl(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
  }).format(value);
}

export function formatAmountValue(value: number): string {
  return value.toFixed(2);
}

/* ---------------------------- chave Pix ---------------------------- */

export function onlyDigits(value: string): string {
  return value.replace(/\D/g, "");
}

export function detectPixKeyType(raw: string): PixKeyType {
  const key = raw.trim();
  if (!key) return "unknown";
  if (/^[\w.+-]+@[\w-]+\.[\w.-]+$/.test(key)) return "email";
  const digits = onlyDigits(key);
  const looksPhone = /^\+?\d[\d\s()-]{9,}$/.test(key) && digits.length >= 10 && digits.length <= 13;
  if (looksPhone) return "phone";
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(key)) return "evp";
  if (digits.length === 11 && !looksPhone) return "cpf";
  if (digits.length === 14) return "cnpj";
  if (digits.length >= 32) return "evp";
  return "unknown";
}

export const PIX_KEY_LABELS: Record<PixKeyType, string> = {
  cpf: "CPF",
  cnpj: "CNPJ",
  email: "E-mail",
  phone: "Celular",
  evp: "Aleatória",
  unknown: "Chave",
};

export function detectPixKeyLabel(key: string): string {
  return PIX_KEY_LABELS[detectPixKeyType(key)];
}

/** Converte a chave para o formato aceito dentro do EMV. */
export function normalizePixKeyForEmv(raw: string): string {
  const key = raw.trim();
  const type = detectPixKeyType(key);
  if (type === "cpf" || type === "cnpj") return onlyDigits(key);
  if (type === "phone") {
    let digits = onlyDigits(key).replace(/^0+/, "");
    if (!digits.startsWith("55")) digits = `55${digits}`;
    return `+${digits}`;
  }
  return key;
}

export function maskPixKey(raw: string): string {
  const key = raw.trim();
  if (!key) return "—";
  const type = detectPixKeyType(key);
  const digits = onlyDigits(key);
  if (type === "cpf" && digits.length === 11) {
    return `***.***.${digits.slice(6, 9)}-${digits.slice(9)}`;
  }
  if (type === "cnpj" && digits.length === 14) {
    return `**.${digits.slice(2, 5)}.${digits.slice(5, 8)}/****-${digits.slice(12)}`;
  }
  if (type === "phone") {
    return `(${digits.slice(-11, -9)}) *****-${digits.slice(-4)}`;
  }
  if (type === "email") {
    const [name, domain] = key.split("@");
    return `${name.slice(0, 2)}***@${domain ?? "•••"}`;
  }
  if (key.length <= 10) return `${key.slice(0, 2)}***${key.slice(-2)}`;
  return `${key.slice(0, 6)}…${key.slice(-4)}`;
}

/* --------------------------- construção --------------------------- */

function tlv(tag: string, value: string): string {
  const safe = value ?? "";
  return `${tag}${safe.length.toString().padStart(2, "0")}${safe}`;
}

function cleanText(value: string, max: number): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w\s.-]/g, "")
    .trim()
    .slice(0, max)
    .toUpperCase();
}

export type BuildEmvInput = {
  key: string;
  amount?: number | null;
  name?: string;
  city?: string;
  description?: string;
  txid?: string;
  keyType?: PixKeyType;
};

export function buildPixEmv({
  key,
  amount,
  name,
  city,
  description,
  txid,
  keyType,
}: BuildEmvInput): string {
  const type = keyType ?? detectPixKeyType(key);
  const normalizedKey = normalizePixKeyForEmv(key);
  const merchantName = cleanText(name || "PIX LINK", 25) || "PIX LINK";
  const merchantCity = cleanText(city || "SAO PAULO", 15) || "SAO PAULO";
  const account = [
    tlv("00", "br.gov.bcb.pix"),
    tlv("01", normalizedKey),
    description ? tlv("02", cleanText(description, 40).slice(0, 40)) : "",
  ].join("");
  const reference = txid ? cleanText(txid, 25).replace(/\s/g, "").slice(0, 25) : "***";
  const parts = [
    tlv("00", "01"),
    tlv("01", "11"),
    tlv("26", account),
    tlv("52", "0000"),
    tlv("53", "986"),
    amount && amount > 0 ? tlv("54", formatAmountValue(amount)) : "",
    tlv("58", "BR"),
    tlv("59", merchantName),
    tlv("60", merchantCity),
    tlv("62", tlv("05", reference || "***")),
    "6304",
  ].join("");
  return `${parts}${crc16(parts)}`;
}

/* --------------------------- validação ---------------------------- */

export type PixInspection = {
  valid: boolean;
  errors: string[];
  warnings: string[];
  amount: number | null;
  amountFromEmv: boolean;
  keyType: PixKeyType | "unknown";
  keyHint: string;
  dynamicUrl: string | null;
  crc: string | null;
  crcExpected: string | null;
  summary: string;
};

export function validatePixEmv(raw: string): PixInspection {
  const emv = sanitizeEmv(raw);
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!emv) {
    return {
      valid: false,
      errors: ["Cole um código Pix copia e cola."],
      warnings,
      amount: null,
      amountFromEmv: false,
      keyType: "unknown",
      keyHint: "",
      dynamicUrl: null,
      crc: null,
      crcExpected: null,
      summary: "",
    };
  }

  if (!emv.startsWith("00")) errors.push("Payload não começa com o campo 00 (Payload Format Indicator).");

  const top = fieldMap(emv);
  const account = top["26"] ? fieldMap(top["26"]) : {};
  const accountAlt = top["25"] ? fieldMap(top["25"]) : {};
  const gui = account["00"] ?? accountAlt["00"] ?? "";
  if (!gui.toLowerCase().includes("br.gov.bcb.pix")) {
    errors.push("Campo 26 não contém a GUI br.gov.bcb.pix — não parece um Pix.");
  }
  const key = account["01"] ?? accountAlt["01"] ?? "";
  if (!key) errors.push("Chave Pix (campo 26/01) ausente.");
  if (!top["53"]) warnings.push("Campo 53 (moeda) ausente.");
  if (top["53"] && top["53"] !== "986") errors.push("Moeda diferente de BRL (986).");
  if (!top["58"]) warnings.push("Campo 58 (país) ausente.");

  const crcIndex = emv.lastIndexOf("6304");
  let crc: string | null = null;
  let crcExpected: string | null = null;
  if (crcIndex >= 0 && crcIndex === emv.length - 8) {
    crc = emv.slice(crcIndex + 4).toUpperCase();
    crcExpected = crc16(emv.slice(0, crcIndex + 4));
    if (crc !== crcExpected) errors.push("CRC inválido — confira se o código foi copiado por completo.");
  } else {
    errors.push("CRC (campo 63) ausente ou fora do padrão.");
  }

  const amountFromEmv = parseEmvAmount(top["54"]);
  const dynamicUrl = account["25"] ?? account["26"] ?? accountAlt["25"] ?? top["25"] ?? null;

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    amount: amountFromEmv,
    amountFromEmv: amountFromEmv !== null,
    keyType: key ? detectPixKeyType(key) : "unknown",
    keyHint: key ? maskPixKey(key) : "",
    dynamicUrl: dynamicUrl && /^https?:\/\//i.test(dynamicUrl) ? dynamicUrl : null,
    crc,
    crcExpected,
    summary: summarizePixEmv(emv),
  };
}

/* ------------------------ extração de valor ----------------------- */

const MONEY_PATTERN = /(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+[.,]\d{2}|\d{1,6})/;

export function extractPixAmountSync(raw: string): number | null {
  const emv = sanitizeEmv(raw);
  if (!emv) return null;

  // 1) Campo 54 no nível raiz.
  const top = fieldMap(emv);
  const fromTag54 = parseEmvAmount(top["54"]);
  if (fromTag54) return fromTag54;

  // 2) Campo 54 em sub-TLVs (alguns bancos aninham).
  for (const field of Object.values(top)) {
    if (field.length > 15 && /^\d{4}/.test(field)) {
      const nested = fieldMap(field);
      const nestedAmount = parseEmvAmount(nested["54"]);
      if (nestedAmount) return nestedAmount;
    }
  }

  // 3) Fallback: descrição / referência com valor textual.
  const account = top["26"] ? fieldMap(top["26"]) : {};
  const extra = top["62"] ? fieldMap(top["62"]) : {};
  const descriptionText = `${account["02"] ?? ""} ${extra["05"] ?? ""} ${top["80"] ?? ""}`;
  if (descriptionText.trim()) {
    const match = descriptionText.match(MONEY_PATTERN);
    if (match) {
      const parsed = normalizeAmountInput(match[1]);
      if (parsed) return parsed;
    }
  }

  // 4) EMV compacto / sem TLV perfeito: procura literalmente "54" + len + valor.
  const compact = emv.match(/54(\d{2})(\d{2,10}[.,]\d{2})/);
  if (compact) {
    const parsed = parseEmvAmount(compact[2]);
    if (parsed) return parsed;
  }

  return null;
}

/**
 * Resolve o valor consultando a URL de location de cobrança dinâmica.
 * Usado no servidor ao validar/criar links de copia e cola.
 */
export async function extractPixAmountRemote(raw: string): Promise<{ amount: number | null; remoteChecked: boolean }> {
  const sync = extractPixAmountSync(raw);
  if (sync) return { amount: sync, remoteChecked: false };
  const url = findDynamicLocation(raw);
  if (!url) return { amount: null, remoteChecked: false };
  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(6500),
      cache: "no-store",
      headers: { accept: "application/json, text/plain, */*" },
    });
    const text = await response.text();
    return { amount: extractAmountFromText(text), remoteChecked: true };
  } catch {
    return { amount: null, remoteChecked: true };
  }
}

/** URL de location de cobrança dinâmica, se existir. */
export function findDynamicLocation(raw: string): string | null {
  const emv = sanitizeEmv(raw);
  const top = fieldMap(emv);
  const candidates = [
    top["26"] ? fieldMap(top["26"])["25"] : undefined,
    top["26"] ? fieldMap(top["26"])["26"] : undefined,
    top["25"] ? fieldMap(top["25"])["25"] : undefined,
    top["25"],
  ].filter(Boolean) as string[];
  for (const candidate of candidates) {
    if (/^https?:\/\//i.test(candidate)) return candidate;
  }
  return null;
}

/** Procura valor em JWT/hash devolvido pela URL de location. */
export function extractAmountFromJwt(token: string): number | null {
  const parts = token.split(".");
  if (parts.length < 2) return null;
  try {
    const payload = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const decodeBase64 = (input: string): string => {
      if (typeof atob === "function") return atob(input);
      return Buffer.from(input, "base64").toString("binary");
    };
    const json = JSON.parse(decodeBase64(payload)) as Record<string, unknown>;
    const stack: unknown[] = [json];
    while (stack.length) {
      const current = stack.pop();
      if (!current || typeof current !== "object") continue;
      for (const [key, value] of Object.entries(current as Record<string, unknown>)) {
        if (typeof value === "number" && /amount|valor|value/i.test(key) && value > 0) {
          // valores em centavos são comuns em JWT
          return value > 100000 ? value / 100 : value;
        }
        if (typeof value === "string") {
          if (/amount|valor|value/i.test(key)) {
            const parsed = normalizeAmountInput(value);
            if (parsed) return parsed;
          }
        } else if (value && typeof value === "object") {
          stack.push(value);
        }
      }
    }
  } catch {
    return null;
  }
  return null;
}

export function extractAmountFromText(text: string): number | null {
  const amountMatch = text.match(/"?(?:amount|valor|value|total)"?\s*[:=]\s*"?(\d+(?:[.,]\d+)?)/i);
  if (amountMatch) {
    const parsed = normalizeAmountInput(amountMatch[1]);
    if (parsed) return parsed;
  }
  const jwtMatch = text.match(/[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/);
  if (jwtMatch) {
    const jwtAmount = extractAmountFromJwt(jwtMatch[0]);
    if (jwtAmount) return jwtAmount;
  }
  const brl = text.match(MONEY_PATTERN);
  if (brl) return normalizeAmountInput(brl[1]);
  return null;
}

/* --------------------------- resumo ------------------------------- */

export function summarizePixEmv(raw: string): string {
  const emv = sanitizeEmv(raw);
  if (!emv) return "";
  if (emv.length <= 28) return emv;
  return `${emv.slice(0, 16)}…${emv.slice(-10)}`;
}
