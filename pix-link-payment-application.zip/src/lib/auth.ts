import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { branding, sessions, users } from "@/db/schema";

export const SESSION_COOKIE = "pixlink_session";
export const MASTER_USERNAME = "Tiagohsa2026";
export const MASTER_PASSWORD = "Gremio1903@";
const SESSION_DAYS = 30;

export type Viewer = {
  id: string;
  name: string;
  username: string;
  role: "master" | "client";
  accessUntil: Date | null;
  expired: boolean;
  daysLeft: number | null;
};

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split("$");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const expected = Buffer.from(hash, "hex");
    const actual = scryptSync(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function toViewer(row: {
  id: string;
  name: string;
  username: string;
  role: string;
  accessUntil: Date | null;
}): Viewer {
  const role: "master" | "client" = row.role === "master" ? "master" : "client";
  const expired = role === "client" && row.accessUntil !== null ? row.accessUntil.getTime() <= Date.now() : false;
  let daysLeft: number | null = null;
  if (row.accessUntil) {
    daysLeft = Math.max(0, Math.ceil((row.accessUntil.getTime() - Date.now()) / 86_400_000));
  }
  return {
    id: row.id,
    name: row.name,
    username: row.username,
    role,
    accessUntil: row.accessUntil,
    expired,
    daysLeft,
  };
}

let bootstrapPromise: Promise<void> | null = null;

/** Cria o master e a linha de branding na primeira execução (idempotente, sem rehash). */
export async function ensureBootstrap(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = (async () => {
      const master = await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.usernameLower, MASTER_USERNAME.toLowerCase()))
        .limit(1);
      if (master.length === 0) {
        await db
          .insert(users)
          .values({
            name: "Tiago",
            username: MASTER_USERNAME,
            usernameLower: MASTER_USERNAME.toLowerCase(),
            passwordHash: hashPassword(MASTER_PASSWORD),
            passwordPlain: MASTER_PASSWORD,
            role: "master",
            accessUntil: null,
          })
          .onConflictDoNothing();
      }
      await db.insert(branding).values({ id: 1, name: "PIX LINK" }).onConflictDoNothing();
    })().catch((error) => {
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

export async function createSession(userId: string): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);
  await db.insert(sessions).values({ id: token, userId, expiresAt });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_DAYS * 86_400,
  });
  return token;
}

export async function destroyCurrentSession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, token)).catch(() => undefined);
  }
  jar.delete(SESSION_COOKIE);
}

export async function getViewer(): Promise<Viewer | null> {
  try {
    await ensureBootstrap();
    const jar = await cookies();
    const token = jar.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const rows = await db
      .select({
        id: users.id,
        name: users.name,
        username: users.username,
        role: users.role,
        accessUntil: users.accessUntil,
      })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.id, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    if (rows.length === 0) return null;
    return toViewer(rows[0]);
  } catch {
    return null;
  }
}

export async function findUserByUsername(username: string) {
  const rows = await db
    .select()
    .from(users)
    .where(eq(users.usernameLower, username.trim().toLowerCase()))
    .limit(1);
  return rows[0] ?? null;
}

export async function nextUsernameAvailable(username: string, ignoreId?: string): Promise<boolean> {
  const rows = await db
    .select({ id: users.id })
    .from(users)
    .where(
      ignoreId
        ? and(eq(users.usernameLower, username.trim().toLowerCase()), sql`${users.id} <> ${ignoreId}`)
        : eq(users.usernameLower, username.trim().toLowerCase()),
    )
    .limit(1);
  return rows.length === 0;
}

export function accessBlocked(viewer: Viewer): boolean {
  return viewer.role === "client" && viewer.expired;
}
