import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { AppearanceForm } from "@/components/appearance-form";
import { getViewer } from "@/lib/auth";
import { getBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

export default async function AppearancePage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");
  if (viewer.role !== "master") redirect("/");
  const brand = await getBranding();

  return (
    <AppShell
      brand={{ name: brand.name, logoData: brand.logoData }}
      viewer={{
        name: viewer.name,
        username: viewer.username,
        role: viewer.role,
        accessUntil: viewer.accessUntil ? viewer.accessUntil.toISOString() : null,
        daysLeft: viewer.daysLeft,
        expired: viewer.expired,
      }}
      active="aparencia"
      title="Aparência"
      subtitle="Nome, logo, favicon e cor do sistema — inclusive na tela do cliente."
    >
      <AppearanceForm initial={brand} />
    </AppShell>
  );
}
