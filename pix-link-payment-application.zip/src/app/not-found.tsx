import Link from "next/link";
import { Icon } from "@/components/icons";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-slate-400 shadow-sm">
        <Icon name="alert" size={26} />
      </span>
      <h1 className="mt-4 text-xl font-extrabold tracking-tight text-slate-900">Página não encontrada</h1>
      <p className="mt-1 max-w-xs text-sm text-slate-500">
        O endereço acessado não existe ou o link de pagamento foi removido.
      </p>
      <Link href="/" className="btn btn-primary mt-5 !py-2.5 !text-sm">
        <Icon name="arrowLeft" size={16} />
        Voltar ao início
      </Link>
    </main>
  );
}
