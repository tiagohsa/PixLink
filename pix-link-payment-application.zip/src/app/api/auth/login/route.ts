import { NextResponse } from "next/server";
import { createSession, ensureBootstrap, findUserByUsername, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { username?: unknown; password?: unknown } | null = null;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Requisição inválida." }, { status: 400 });
  }
  const username = typeof body?.username === "string" ? body.username.trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!username || !password) {
    return NextResponse.json({ error: "Informe usuário e senha." }, { status: 400 });
  }

  try {
    await ensureBootstrap();
    const user = await findUserByUsername(username);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: "Usuário ou senha inválidos." }, { status: 401 });
    }
    await createSession(user.id);
    return NextResponse.json({ ok: true, role: user.role });
  } catch {
    return NextResponse.json(
      { error: "Não foi possível entrar agora. Verifique a conexão e tente novamente." },
      { status: 500 },
    );
  }
}
