import { NextResponse } from "next/server";
import { getLinkRow, isExpired } from "@/lib/links";

export const dynamic = "force-dynamic";

/** EMV entregue apenas no momento da cópia — a tela do cliente nunca o expõe no HTML. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const row = await getLinkRow(id);
  if (!row) return NextResponse.json({ error: "Pagamento não encontrado." }, { status: 404 });
  if (isExpired(row)) return NextResponse.json({ error: "Este pagamento expirou." }, { status: 410 });
  if (row.payStatus === "paid") {
    return NextResponse.json({ error: "Pagamento já efetuado.", payStatus: "paid" }, { status: 409 });
  }
  return NextResponse.json(
    { emv: row.emv },
    { headers: { "cache-control": "no-store, max-age=0" } },
  );
}
