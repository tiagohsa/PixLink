import { NextResponse } from "next/server";
import { requireViewer, jsonError } from "@/lib/api";
import { deleteLink } from "@/lib/links";

export const dynamic = "force-dynamic";

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;
  const { id } = await params;
  const removed = await deleteLink(guard.viewer.id, id);
  if (!removed) return jsonError("Link não encontrado.", 404);
  return NextResponse.json({ ok: true });
}
