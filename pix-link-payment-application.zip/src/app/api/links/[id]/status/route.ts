import { NextResponse } from "next/server";
import { getLinkRow, isExpired, refreshPaidStatus } from "@/lib/links";

export const dynamic = "force-dynamic";

const lastCheck = new Map<string, number>();

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const row = await getLinkRow(id);
  if (!row) return NextResponse.json({ state: "notfound" }, { status: 404 });
  if (isExpired(row)) return NextResponse.json({ state: "expired", payStatus: row.payStatus });

  let current = row;
  const canRefresh =
    row.provider && row.payStatus !== "paid" && row.remoteId && Date.now() - (lastCheck.get(id) ?? 0) > 8000;
  if (canRefresh) {
    lastCheck.set(id, Date.now());
    current = await refreshPaidStatus(row);
  }

  return NextResponse.json({
    state: "ok",
    payStatus: current.payStatus === "paid" ? "paid" : "pending",
    tracked: Boolean(current.provider),
  });
}
