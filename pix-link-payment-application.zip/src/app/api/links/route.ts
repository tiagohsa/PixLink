import { NextResponse } from "next/server";
import { requireViewer, jsonError } from "@/lib/api";
import { createLink, listLinks } from "@/lib/links";
import {
  buildPixEmv,
  detectPixKeyType,
  extractPixAmountRemote,
  extractPixAmountSync,
  normalizeAmountInput,
  sanitizeEmv,
  validatePixEmv,
} from "@/lib/pix";

export const dynamic = "force-dynamic";

export async function GET() {
  const guard = await requireViewer();
  if (guard.response) return guard.response;
  const links = await listLinks(guard.viewer.id);
  return NextResponse.json({ links });
}

export async function POST(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const kind = body.kind === "copy" ? "copy" : "key";
  const description = typeof body.description === "string" ? body.description.trim().slice(0, 140) : "";
  const amountInput = normalizeAmountInput(
    typeof body.amount === "number" || typeof body.amount === "string" ? body.amount : null,
  );

  if (kind === "key") {
    const key = typeof body.key === "string" ? body.key.trim() : "";
    if (!key) return jsonError("Informe a chave Pix.");
    const keyType = detectPixKeyType(key);
    if (keyType === "unknown") return jsonError("Chave Pix não reconhecida. Use CPF, CNPJ, e-mail, celular ou chave aleatória.");

    const validityHours = Number(body.validityValue) * (body.validityUnit === "minutes" ? 1 / 60 : 1);
    const expiresAt =
      Number.isFinite(validityHours) && validityHours > 0
        ? new Date(Date.now() + validityHours * 3_600_000)
        : null;

    const emv = buildPixEmv({
      key,
      keyType,
      amount: amountInput,
      name: typeof body.recipientName === "string" ? body.recipientName : "",
      city: typeof body.recipientCity === "string" ? body.recipientCity : "",
      description,
    });
    const link = await createLink({
      userId: guard.viewer.id,
      emv,
      amount: amountInput,
      keyHint: key,
      kind: "key",
      description: description || null,
      expiresAt,
    });
    return NextResponse.json({ link });
  }

  const emv = sanitizeEmv(typeof body.emv === "string" ? body.emv : "");
  if (!emv) return jsonError("Cole o código Pix copia e cola.");
  const inspection = validatePixEmv(emv);
  if (!inspection.valid) return jsonError(inspection.errors[0] ?? "Código Pix inválido.");
  const remote = await extractPixAmountRemote(emv);
  const extracted = remote.amount ?? extractPixAmountSync(emv) ?? amountInput;
  const link = await createLink({
    userId: guard.viewer.id,
    emv,
    amount: extracted,
    keyHint: null,
    kind: "copy",
    description: description || null,
    expiresAt: null,
  });
  return NextResponse.json({ link, warnings: inspection.warnings });
}
