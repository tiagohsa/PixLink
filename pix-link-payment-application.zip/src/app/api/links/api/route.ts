import { NextResponse } from "next/server";
import { getGatewayForUser, jsonError, requestOrigin, requireViewer } from "@/lib/api";
import { createLink } from "@/lib/links";
import { normalizeAmountInput } from "@/lib/pix";
import { createProviderCharge, isProviderId, providerLabel } from "@/lib/providers";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const provider = body.provider;
  if (!isProviderId(provider)) return jsonError("Escolha uma API conectada.");
  const amount = normalizeAmountInput(
    typeof body.amount === "number" || typeof body.amount === "string" ? body.amount : null,
  );
  if (!amount) return jsonError("Informe o valor da cobrança.");
  const description =
    typeof body.description === "string" && body.description.trim()
      ? body.description.trim().slice(0, 120)
      : `Cobrança Pix · ${providerLabel(provider)}`;

  const gateway = await getGatewayForUser(guard.viewer.id, provider);
  if (!gateway) return jsonError(`Conecte a ${providerLabel(provider)} em Integrações primeiro.`, 409);

  const externalId = `pl${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`.slice(0, 20);
  const outcome = await createProviderCharge(provider, gateway.credentials, gateway.sandbox, {
    amount,
    description,
    externalId,
    webhookBase: requestOrigin(request),
  });

  if (!outcome.ok) return jsonError(outcome.error, 422);

  const link = await createLink({
    userId: guard.viewer.id,
    emv: outcome.data.emv,
    amount,
    keyHint: providerLabel(provider),
    provider,
    remoteId: outcome.data.remoteId,
    payStatus: "pending",
    kind: "api",
    description,
    expiresAt: null,
  });

  return NextResponse.json({ link });
}
