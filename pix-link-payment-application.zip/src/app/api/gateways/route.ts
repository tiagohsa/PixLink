import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentGateways } from "@/db/schema";
import { jsonError, requireViewer } from "@/lib/api";
import { PROVIDERS, isProviderId } from "@/lib/providers";

export const dynamic = "force-dynamic";

function maskSecret(value: string): string {
  if (!value) return "";
  if (value.length <= 6) return "••••";
  return `${value.slice(0, 4)}…${value.slice(-3)}`;
}

export async function GET() {
  const guard = await requireViewer();
  if (guard.response) return guard.response;
  const rows = await db.select().from(paymentGateways).where(eq(paymentGateways.userId, guard.viewer.id));
  const connected = rows.map((row) => {
    const meta = PROVIDERS.find((provider) => provider.id === row.provider);
    const hints = meta
      ? meta.fields
          .map((field) => ({ label: field.label, value: maskSecret(row.credentials[field.key] ?? "") }))
          .filter((item) => item.value)
      : [];
    return {
      provider: row.provider,
      sandbox: row.sandbox,
      hints,
      createdAt: row.createdAt.toISOString(),
    };
  });
  return NextResponse.json({ connected });
}

export async function POST(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const provider = body.provider;
  if (!isProviderId(provider)) return jsonError("Provedor inválido.");
  const meta = PROVIDERS.find((item) => item.id === provider);
  if (!meta) return jsonError("Provedor inválido.");

  const rawCredentials =
    body.credentials && typeof body.credentials === "object"
      ? (body.credentials as Record<string, unknown>)
      : {};
  const credentials: Record<string, string> = {};
  for (const field of meta.fields) {
    const value = rawCredentials[field.key];
    if (typeof value === "string" && value.trim()) credentials[field.key] = value.trim();
  }
  for (const field of meta.fields) {
    if (!field.optional && !credentials[field.key]) {
      return jsonError(`Informe ${field.label}.`);
    }
  }
  const sandbox = Boolean(body.sandbox) && meta.hasSandbox;

  await db
    .insert(paymentGateways)
    .values({ userId: guard.viewer.id, provider, credentials, sandbox })
    .onConflictDoUpdate({
      target: [paymentGateways.userId, paymentGateways.provider],
      set: { credentials, sandbox },
    });

  return NextResponse.json({ ok: true, provider, sandbox });
}

export async function DELETE(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;
  const provider = new URL(request.url).searchParams.get("provider");
  if (!isProviderId(provider)) return jsonError("Provedor inválido.");
  await db
    .delete(paymentGateways)
    .where(and(eq(paymentGateways.userId, guard.viewer.id), eq(paymentGateways.provider, provider)));
  return NextResponse.json({ ok: true });
}
