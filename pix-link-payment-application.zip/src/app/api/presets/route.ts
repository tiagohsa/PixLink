import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { userPresets } from "@/db/schema";
import { jsonError, requireViewer } from "@/lib/api";
import { detectPixKeyType, normalizeAmountInput } from "@/lib/pix";

export const dynamic = "force-dynamic";

async function loadPresets(userId: string) {
  const rows = await db.select().from(userPresets).where(eq(userPresets.userId, userId)).limit(1);
  return {
    pixKeys: rows[0]?.pixKeys ?? [],
    amounts: rows[0]?.amounts ?? [],
  };
}

export async function GET() {
  const guard = await requireViewer();
  if (guard.response) return guard.response;
  return NextResponse.json(await loadPresets(guard.viewer.id));
}

export async function POST(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const kind = body.kind === "amount" ? "amount" : "key";
  const action = body.action === "remove" ? "remove" : "add";
  const current = await loadPresets(guard.viewer.id);

  let pixKeys = [...current.pixKeys];
  let amounts = [...current.amounts];

  if (action === "remove") {
    const value = typeof body.value === "string" ? body.value.trim() : "";
    if (kind === "key") pixKeys = pixKeys.filter((item) => item !== value);
    else amounts = amounts.filter((item) => item !== value);
  } else if (kind === "key") {
    const key = typeof body.value === "string" ? body.value.trim() : "";
    if (!key) return jsonError("Informe a chave Pix.");
    if (detectPixKeyType(key) === "unknown") return jsonError("Chave Pix não reconhecida.");
    if (!pixKeys.includes(key)) {
      if (pixKeys.length >= 3) return jsonError("Limite de 3 chaves salvas. Remova uma para adicionar outra.");
      pixKeys = [...pixKeys, key];
    }
  } else {
    const parsed = normalizeAmountInput(
      typeof body.value === "number" || typeof body.value === "string" ? body.value : null,
    );
    if (!parsed) return jsonError("Valor inválido.");
    const value = parsed.toFixed(2);
    if (!amounts.includes(value)) {
      if (amounts.length >= 3) return jsonError("Limite de 3 valores salvos. Remova um para adicionar outro.");
      amounts = [...amounts, value];
    }
  }

  await db
    .insert(userPresets)
    .values({ userId: guard.viewer.id, pixKeys, amounts, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: userPresets.userId,
      set: { pixKeys, amounts, updatedAt: new Date() },
    });

  return NextResponse.json({ pixKeys, amounts });
}
