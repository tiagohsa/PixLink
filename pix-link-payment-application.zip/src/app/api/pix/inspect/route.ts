import { NextResponse } from "next/server";
import { jsonError, requireViewer } from "@/lib/api";
import {
  extractPixAmountRemote,
  sanitizeEmv,
  summarizePixEmv,
  validatePixEmv,
} from "@/lib/pix";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const guard = await requireViewer();
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }
  const emv = sanitizeEmv(typeof body.emv === "string" ? body.emv : "");
  if (!emv) return jsonError("Cole o código Pix copia e cola.");

  const inspection = validatePixEmv(emv);
  const remote = await extractPixAmountRemote(emv);

  return NextResponse.json({
    valid: inspection.valid,
    errors: inspection.errors,
    warnings: inspection.warnings,
    amount: remote.amount,
    amountFromEmv: inspection.amountFromEmv,
    remoteChecked: remote.remoteChecked,
    keyType: inspection.keyType,
    keyHint: inspection.keyHint,
    summary: summarizePixEmv(emv),
    crcOk: inspection.crc !== null && inspection.crc === inspection.crcExpected,
  });
}
