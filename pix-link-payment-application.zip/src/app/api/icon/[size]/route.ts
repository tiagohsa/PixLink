import { getBranding } from "@/lib/branding";
import { dataUrlToBuffer, makeBrandIconPng } from "@/lib/png";

export const dynamic = "force-dynamic";

const ALLOWED = new Set([32, 180, 192, 512]);

export async function GET(_request: Request, { params }: { params: Promise<{ size: string }> }) {
  const { size } = await params;
  const requested = Number(size);
  const px = ALLOWED.has(requested) ? requested : 192;
  const brand = await getBranding();

  const candidate =
    px === 32
      ? (brand.faviconData ?? brand.iconData ?? brand.logoData)
      : px === 180
        ? (brand.iconData ?? brand.logoData ?? brand.faviconData)
        : (brand.iconData ?? brand.logoData);

  if (candidate) {
    const decoded = dataUrlToBuffer(candidate);
    if (decoded && /^image\/(png|jpeg|webp)$/.test(decoded.mime)) {
      return new Response(new Uint8Array(decoded.buffer), {
        headers: {
          "content-type": decoded.mime,
          "cache-control": "public, max-age=300, must-revalidate",
        },
      });
    }
    if (decoded && decoded.mime === "image/svg+xml" && px === 32) {
      return new Response(new Uint8Array(decoded.buffer), {
        headers: { "content-type": decoded.mime, "cache-control": "public, max-age=300" },
      });
    }
  }

  const png = makeBrandIconPng(px, brand.color);
  return new Response(new Uint8Array(png), {
    headers: {
      "content-type": "image/png",
      "cache-control": "public, max-age=300, must-revalidate",
    },
  });
}
