import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { branding } from "@/db/schema";
import { jsonError, requireViewer } from "@/lib/api";
import { isHexColor } from "@/lib/branding";

export const dynamic = "force-dynamic";
const MAX_DATA_URL = 700_000;

function cleanDataUrl(value: unknown, field: string): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  if (typeof value !== "string") throw new Error(`Imagem inválida em ${field}.`);
  if (value.length > MAX_DATA_URL) throw new Error(`A imagem de ${field} é muito grande (máx. ~500 KB).`);
  if (!/^data:image\/(png|jpeg|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/.test(value)) {
    throw new Error(`Formato de imagem inválido em ${field}. Use PNG, JPG, WEBP ou SVG.`);
  }
  return value;
}

export async function POST(request: Request) {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const name = typeof body.name === "string" ? body.name.trim().slice(0, 40) : "";
  const color = typeof body.color === "string" ? body.color.trim() : "";
  if (!name) return jsonError("Informe o nome do sistema.");
  if (!isHexColor(color)) return jsonError("Escolha uma cor válida.");

  try {
    const logo = cleanDataUrl(body.logoData, "logo");
    const icon = cleanDataUrl(body.iconData, "ícone");
    const favicon = cleanDataUrl(body.faviconData, "favicon");

    const values = {
      id: 1,
      name,
      color,
      updatedAt: new Date(),
      ...(logo !== undefined ? { logoData: logo } : {}),
      ...(icon !== undefined ? { iconData: icon } : {}),
      ...(favicon !== undefined ? { faviconData: favicon } : {}),
    };

    await db.insert(branding).values(values).onConflictDoUpdate({
      target: branding.id,
      set: values,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Não foi possível salvar a aparência.");
  }
}

export async function GET() {
  const rows = await db.select().from(branding).where(eq(branding.id, 1)).limit(1);
  const row = rows[0];
  return NextResponse.json({
    branding: {
      name: row?.name ?? "PIX LINK",
      color: row?.color ?? "#0f9d76",
      logoData: row?.logoData ?? null,
      iconData: row?.iconData ?? null,
      faviconData: row?.faviconData ?? null,
    },
  });
}
