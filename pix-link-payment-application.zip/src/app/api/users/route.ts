import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { userPresets, users } from "@/db/schema";
import { hashPassword, nextUsernameAvailable } from "@/lib/auth";
import { jsonError, requireViewer } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;
  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      username: users.username,
      passwordPlain: users.passwordPlain,
      role: users.role,
      accessUntil: users.accessUntil,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(asc(users.createdAt));
  return NextResponse.json({
    users: rows.map((row) => ({
      ...row,
      accessUntil: row.accessUntil ? row.accessUntil.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
      expired: row.accessUntil ? row.accessUntil.getTime() <= Date.now() : false,
      daysLeft: row.accessUntil
        ? Math.max(0, Math.ceil((row.accessUntil.getTime() - Date.now()) / 86_400_000))
        : null,
    })),
  });
}

export async function POST(request: Request) {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const username = typeof body.username === "string" ? body.username.trim() : "";
  const password = typeof body.password === "string" ? body.password : "";
  const rawDays = body.days;
  const days = rawDays === "" || rawDays === null || rawDays === undefined ? null : Number(rawDays);

  if (!name) return jsonError("Informe o nome.");
  if (!username || username.length < 3) return jsonError("Usuário deve ter pelo menos 3 caracteres.");
  if (!/^[A-Za-z0-9._-]+$/.test(username)) return jsonError("Usuário aceita apenas letras, números, ponto, hífen e sublinhado.");
  if (password.length < 4) return jsonError("A senha deve ter pelo menos 4 caracteres.");
  if (days !== null && (!Number.isFinite(days) || days <= 0)) return jsonError("Dias de acesso inválido.");
  if (!(await nextUsernameAvailable(username))) return jsonError("Este usuário já existe.", 409);

  const accessUntil = days !== null ? new Date(Date.now() + Math.round(days) * 86_400_000) : null;

  try {
    const inserted = await db
      .insert(users)
      .values({
        name,
        username,
        usernameLower: username.toLowerCase(),
        passwordHash: hashPassword(password),
        passwordPlain: password,
        role: "client",
        accessUntil,
      })
      .returning({ id: users.id, name: users.name, username: users.username });
    if (inserted[0]) {
      await db.insert(userPresets).values({ userId: inserted[0].id }).onConflictDoNothing();
    }
    return NextResponse.json({ ok: true, user: inserted[0] });
  } catch {
    return jsonError("Não foi possível criar o usuário.", 500);
  }
}

export async function DELETE() {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;
  return jsonError("Use a lista para excluir um usuário.", 405);
}

export async function PATCH() {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;
  const own = await db.select({ id: users.id }).from(users).where(eq(users.id, guard.viewer.id)).limit(1);
  return NextResponse.json({ ok: Boolean(own[0]) });
}
