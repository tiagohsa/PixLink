import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, nextUsernameAvailable } from "@/lib/auth";
import { jsonError, requireViewer } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;
  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return jsonError("Requisição inválida.");
  }

  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  const current = rows[0];
  if (!current) return jsonError("Usuário não encontrado.", 404);

  const name = typeof body.name === "string" && body.name.trim() ? body.name.trim() : current.name;
  const username =
    typeof body.username === "string" && body.username.trim() ? body.username.trim() : current.username;
  const password =
    typeof body.password === "string" && body.password.trim() ? body.password.trim() : null;
  const rawDays = body.days;
  const days = rawDays === "" || rawDays === null || rawDays === undefined ? null : Number(rawDays);

  if (username !== current.username) {
    if (!/^[A-Za-z0-9._-]+$/.test(username) || username.length < 3) {
      return jsonError("Usuário inválido (mínimo 3 caracteres, sem espaços).");
    }
    if (!(await nextUsernameAvailable(username, id))) return jsonError("Este usuário já existe.", 409);
  }
  if (password !== null && password.length < 4) return jsonError("A senha deve ter pelo menos 4 caracteres.");
  if (days !== null && (!Number.isFinite(days) || days <= 0)) return jsonError("Dias de acesso inválido.");

  const accessUntil =
    current.role === "master"
      ? null
      : days !== null
        ? new Date(Date.now() + Math.round(days) * 86_400_000)
        : null;

  const updated = await db
    .update(users)
    .set({
      name,
      username,
      usernameLower: username.toLowerCase(),
      accessUntil,
      ...(password ? { passwordHash: hashPassword(password), passwordPlain: password } : {}),
    })
    .where(eq(users.id, id))
    .returning({
      id: users.id,
      name: users.name,
      username: users.username,
      role: users.role,
      accessUntil: users.accessUntil,
    });

  return NextResponse.json({
    ok: true,
    user: updated[0]
      ? {
          ...updated[0],
          accessUntil: updated[0].accessUntil ? updated[0].accessUntil.toISOString() : null,
        }
      : null,
  });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireViewer({ master: true });
  if (guard.response) return guard.response;
  const { id } = await params;

  const rows = await db.select({ role: users.role }).from(users).where(eq(users.id, id)).limit(1);
  const target = rows[0];
  if (!target) return jsonError("Usuário não encontrado.", 404);
  if (target.role === "master") return jsonError("A conta master não pode ser excluída.", 403);

  await db.delete(users).where(eq(users.id, id));
  return NextResponse.json({ ok: true });
}
