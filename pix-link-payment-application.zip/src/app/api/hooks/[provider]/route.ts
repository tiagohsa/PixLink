import { NextResponse } from "next/server";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { pixLinks } from "@/db/schema";
import { refreshPaidStatus } from "@/lib/links";
import { isProviderId } from "@/lib/providers";

export const dynamic = "force-dynamic";

const SHORT_ID = /^[abcdefghjkmnpqrstuvwxyz23456789]{4}$/;
const PAID_STATUS = /^(paid|approved|confirmed|received|completed|succeeded|pago|concluido|recebido|received_in_cash)$/i;
const PAID_EVENT = /(payment[._-]?(received|approved|confirmed)|charge[._-]?paid|transaction[._-]?paid|pix[._-]?received|PAYMENT_RECEIVED|PAYMENT_CONFIRMED)/i;

function walk(value: unknown, depth: number, ids: Set<string>, statuses: Set<string>) {
  if (depth > 7 || value === null || value === undefined) return;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (trimmed.length >= 3 && trimmed.length <= 90) ids.add(trimmed);
    if (trimmed.length > 0 && trimmed.length <= 40) statuses.add(trimmed);
    return;
  }
  if (typeof value === "number") {
    ids.add(String(value));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) walk(item, depth + 1, ids, statuses);
    return;
  }
  if (typeof value === "object") {
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      if (/status|state|situation|event|action|type/i.test(key) && typeof item === "string") {
        statuses.add(item.trim());
      }
      walk(item, depth + 1, ids, statuses);
    }
  }
}

export async function POST(request: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  if (!isProviderId(provider)) {
    return NextResponse.json({ ok: false, error: "Provedor desconhecido." }, { status: 404 });
  }

  const raw = await request.text();
  let payload: unknown = {};
  try {
    payload = JSON.parse(raw);
  } catch {
    const form = new URLSearchParams(raw);
    payload = Object.fromEntries(form.entries());
  }

  const ids = new Set<string>();
  const statuses = new Set<string>();
  walk(payload, 0, ids, statuses);

  const explicitlyPaid =
    [...statuses].some((status) => PAID_STATUS.test(status)) || PAID_EVENT.test(raw);

  const candidateIds = [...ids].filter((value) => value.length <= 90).slice(0, 40);
  const shortIds = candidateIds.filter((value) => SHORT_ID.test(value));

  let rows: Array<typeof pixLinks.$inferSelect> = [];
  if (candidateIds.length > 0) {
    rows = await db
      .select()
      .from(pixLinks)
      .where(and(eq(pixLinks.provider, provider), inArray(pixLinks.remoteId, candidateIds)))
      .limit(20);
  }
  if (shortIds.length > 0) {
    const byLink = await db
      .select()
      .from(pixLinks)
      .where(and(eq(pixLinks.provider, provider), inArray(pixLinks.id, shortIds)))
      .limit(20);
    rows = [...rows, ...byLink];
  }

  const unique = new Map(rows.map((row) => [row.id, row]));
  let updated = 0;

  for (const row of unique.values()) {
    if (row.payStatus === "paid") continue;
    if (explicitlyPaid) {
      await db.update(pixLinks).set({ payStatus: "paid" }).where(eq(pixLinks.id, row.id));
      updated += 1;
      continue;
    }
    // Webhook só avisou "atualizado": confirma o status real na API do provedor.
    const refreshed = await refreshPaidStatus(row);
    if (refreshed.payStatus === "paid") updated += 1;
  }

  return NextResponse.json({ ok: true, provider, updated });
}

export async function GET(_request: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  return NextResponse.json({
    ok: isProviderId(provider),
    provider,
    message: "Webhook ativo. Configure esta URL no painel do provedor.",
  });
}
