import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentGateways, userPresets } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { Generator } from "@/components/generator";
import { BrandMark, Icon } from "@/components/icons";
import { LogoutButton } from "@/components/logout-button";
import { getViewer } from "@/lib/auth";
import { getBranding } from "@/lib/branding";
import { listLinks } from "@/lib/links";
import { PROVIDERS } from "@/lib/providers";

export const dynamic = "force-dynamic";

export default async function GeneratorPage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");
  const brand = await getBranding();

  if (viewer.expired) {
    return (
      <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-10">
        <div className="fade-up card p-6 text-center">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-600">
            <Icon name="clock" size={22} />
          </span>
          <h1 className="mt-3 text-xl font-extrabold text-slate-900">Seu acesso expirou</h1>
          <p className="mt-1 text-sm leading-relaxed text-slate-500">
            Olá, {viewer.name.split(" ")[0]}. O prazo da sua conta terminou e o gerador de links está
            bloqueado. Peça ao administrador para renovar seus dias de acesso.
          </p>
          <div className="mt-5 space-y-2">
            <LogoutButton className="btn btn-primary w-full !py-3" label="Voltar ao login" />
          </div>
        </div>
      </main>
    );
  }

  const [presetRows, links, gatewayRows] = await Promise.all([
    db.select().from(userPresets).where(eq(userPresets.userId, viewer.id)).limit(1),
    listLinks(viewer.id),
    db.select().from(paymentGateways).where(eq(paymentGateways.userId, viewer.id)),
  ]);

  const gateways = gatewayRows.map((row) => ({
    provider: row.provider,
    sandbox: row.sandbox,
    name: PROVIDERS.find((item) => item.id === row.provider)?.name ?? row.provider,
  }));

  return (
    <AppShell
      brand={{ name: brand.name, logoData: brand.logoData }}
      viewer={{
        name: viewer.name,
        username: viewer.username,
        role: viewer.role,
        accessUntil: viewer.accessUntil ? viewer.accessUntil.toISOString() : null,
        daysLeft: viewer.daysLeft,
        expired: viewer.expired,
      }}
      active="gerador"
    >
      <div className="fade-up mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-slate-900">Gerador de links</h1>
          <p className="mt-0.5 text-sm text-slate-500">
            Crie um link curto de pagamento em segundos.
          </p>
        </div>
        <BrandMark logoData={brand.logoData} name={brand.name} size={40} />
      </div>
      <Generator
        initialLinks={links}
        initialPresets={{
          pixKeys: presetRows[0]?.pixKeys ?? [],
          amounts: presetRows[0]?.amounts ?? [],
        }}
        gateways={gateways}
      />
    </AppShell>
  );
}
