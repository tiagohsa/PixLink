import type { Metadata } from "next";
import QRCode from "qrcode";
import { Checkout, PublicState } from "@/components/checkout";
import { getBranding } from "@/lib/branding";
import { getLinkRow, toPublicView } from "@/lib/links";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getBranding();
  return {
    title: `Pagamento · ${brand.name}`,
    description: "Pague com Pix de forma rápida e segura.",
    robots: { index: false, follow: false },
    manifest: "/manifest.webmanifest",
  };
}

export default async function PublicCheckoutPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const brand = await getBranding();

  const row = await getLinkRow(id);
  if (!row) {
    return (
      <PublicState
        brandName={brand.name}
        logoData={brand.logoData}
        title="Pagamento não encontrado"
        message="Este link não existe ou foi removido. Confira o endereço recebido."
      />
    );
  }

  const view = toPublicView(row);
  if (view.state === "expired") {
    return (
      <PublicState
        brandName={brand.name}
        logoData={brand.logoData}
        title="Este pagamento expirou"
        message="O prazo deste link terminou. Peça um novo link a quem enviou a cobrança."
      />
    );
  }
  if (view.state !== "ok") {
    return (
      <PublicState
        brandName={brand.name}
        logoData={brand.logoData}
        title="Pagamento não encontrado"
        message="Este link não existe ou foi removido."
      />
    );
  }

  let qrDataUrl: string | null = null;
  try {
    qrDataUrl = await QRCode.toDataURL(view.emv, {
      width: 720,
      margin: 1,
      errorCorrectionLevel: "M",
      color: { dark: "#0f172a", light: "#ffffff" },
    });
  } catch {
    qrDataUrl = null;
  }

  return (
    <Checkout
      id={view.id}
      brandName={brand.name}
      logoData={brand.logoData}
      amount={view.amount}
      summary={view.summary}
      qrDataUrl={qrDataUrl}
      payStatus={view.payStatus}
      tracked={view.tracked}
    />
  );
}
