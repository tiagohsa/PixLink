import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentGateways } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { Integrations } from "@/components/integrations";
import { getViewer } from "@/lib/auth";
import { getBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

export default async function IntegrationsPage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");
  if (viewer.expired) redirect("/");
  const brand = await getBranding();

  const rows = await db.select().from(paymentGateways).where(eq(paymentGateways.userId, viewer.id));

  return (
    <AppShell
      brand={{ name: brand.name, logoData: brand.logoData }}
      viewer={{
        name: viewer.name,
        username: viewer.username,
        role: viewer.role,
        accessUntil: viewer.accessUntil ? viewer.accessUntil.toISOString() : null,
        daysLeft: viewer.daysLeft,
        expired: viewer.expired,
      }}
      active="integracoes"
      title="Integrações"
      subtitle="Conecte as suas chaves para gerar cobranças com status de pagamento."
    >
      <Integrations
        initialConnected={rows.map((row) => ({
          provider: row.provider,
          sandbox: row.sandbox,
          createdAt: row.createdAt.toISOString(),
        }))}
      />
    </AppShell>
  );
}
