import { redirect } from "next/navigation";
import { BrandMark, Icon } from "@/components/icons";
import { LoginForm } from "@/components/login-form";
import { getViewer } from "@/lib/auth";
import { getBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const viewer = await getViewer();
  if (viewer) redirect("/");
  const brand = await getBranding();

  return (
    <main className="flex min-h-dvh flex-col">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 py-8">
        <div className="fade-up flex items-center gap-3">
          <BrandMark logoData={brand.logoData} name={brand.name} size={44} />
          <div>
            <p className="text-lg font-extrabold tracking-tight text-slate-900">{brand.name}</p>
            <p className="text-xs font-medium text-slate-500">Links de pagamento Pix</p>
          </div>
        </div>

        <div className="fade-up card mt-7 p-6">
          <span className="badge bg-[var(--brand-soft)] text-[var(--brand-dark)]">
            <Icon name="shield" size={12} />
            Área do operador
          </span>
          <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-slate-900">
            Entre na sua conta
          </h1>
          <p className="mt-1 text-sm leading-relaxed text-slate-500">
            Use o usuário e a senha cadastrados. Cada operador vê apenas os próprios links, chaves e
            integrações.
          </p>
          <LoginForm />
        </div>

        <div className="mt-5 grid grid-cols-3 gap-2 text-center">
          {[
            { icon: "zap" as const, label: "Link em 4 caracteres" },
            { icon: "shield" as const, label: "Checkout discreto" },
            { icon: "qr" as const, label: "Pix copia e cola" },
          ].map((item) => (
            <div key={item.label} className="card px-2 py-3">
              <span className="mx-auto flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--brand-soft)] text-[var(--brand-dark)]">
                <Icon name={item.icon} size={15} />
              </span>
              <p className="mt-2 text-[11px] font-semibold leading-tight text-slate-600">
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </div>
      <footer className="safe-bottom px-5 pb-4 text-center text-[11px] font-medium text-slate-400">
        pagamento 100% seguro. ©2026
      </footer>
    </main>
  );
}
