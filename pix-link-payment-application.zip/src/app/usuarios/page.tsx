import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { UsersAdmin } from "@/components/users-admin";
import { getViewer } from "@/lib/auth";
import { getBranding } from "@/lib/branding";

export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");
  if (viewer.role !== "master") redirect("/");
  const brand = await getBranding();

  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      username: users.username,
      passwordPlain: users.passwordPlain,
      role: users.role,
      accessUntil: users.accessUntil,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(asc(users.createdAt));

  return (
    <AppShell
      brand={{ name: brand.name, logoData: brand.logoData }}
      viewer={{
        name: viewer.name,
        username: viewer.username,
        role: viewer.role,
        accessUntil: viewer.accessUntil ? viewer.accessUntil.toISOString() : null,
        daysLeft: viewer.daysLeft,
        expired: viewer.expired,
      }}
      active="usuarios"
      title="Usuários"
      subtitle="Crie e gerencie os operadores. Cada um vê apenas os próprios dados."
    >
      <UsersAdmin
        initialUsers={rows.map((row) => ({
          id: row.id,
          name: row.name,
          username: row.username,
          passwordPlain: row.passwordPlain,
          role: row.role,
          accessUntil: row.accessUntil ? row.accessUntil.toISOString() : null,
          createdAt: row.createdAt.toISOString(),
        }))}
      />
    </AppShell>
  );
}
