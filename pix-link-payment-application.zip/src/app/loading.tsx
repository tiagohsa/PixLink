export default function Loading() {
  return (
    <main className="mx-auto w-full max-w-3xl px-4 pb-20 pt-20">
      <div className="flex items-center gap-3">
        <div className="skeleton h-10 w-10 rounded-xl" />
        <div className="space-y-2">
          <div className="skeleton h-4 w-32 rounded-full" />
          <div className="skeleton h-3 w-44 rounded-full" />
        </div>
      </div>
      <div className="card mt-5 space-y-3 p-4">
        <div className="skeleton h-10 w-full rounded-xl" />
        <div className="skeleton h-12 w-full rounded-xl" />
        <div className="skeleton h-12 w-full rounded-xl" />
        <div className="skeleton h-12 w-full rounded-xl" />
      </div>
      <p className="mt-4 text-center text-xs font-medium text-slate-400">Carregando…</p>
    </main>
  );
}
