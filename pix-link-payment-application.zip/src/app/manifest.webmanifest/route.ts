import { getBranding, mixWithWhite } from "@/lib/branding";

export const dynamic = "force-dynamic";

export async function GET() {
  const brand = await getBranding();
  const manifest = {
    name: `${brand.name} · Links Pix`,
    short_name: brand.name.slice(0, 14),
    description: "Gere links curtos de pagamento Pix em segundos.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    lang: "pt-BR",
    dir: "ltr",
    background_color: mixWithWhite(brand.color, 0.92),
    theme_color: brand.color,
    icons: [
      { src: "/api/icon/192", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/api/icon/512", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/api/icon/512", sizes: "512x512", type: "image/png", purpose: "maskable" },
      { src: "/api/icon/180", sizes: "180x180", type: "image/png", purpose: "any" },
    ],
  };
  return new Response(JSON.stringify(manifest), {
    headers: {
      "content-type": "application/manifest+json; charset=utf-8",
      "cache-control": "no-store, max-age=0",
    },
  });
}
