import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { getBranding, brandVars } from "@/lib/branding";
import { PwaRegister } from "@/components/pwa-register";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const brand = await getBranding();
  return {
    title: `${brand.name} · Links de pagamento Pix`,
    description: "Gere links curtos de pagamento Pix em segundos. Checkout limpo, sem burocracia.",
    applicationName: brand.name,
    manifest: "/manifest.webmanifest",
    appleWebApp: {
      capable: true,
      title: brand.name,
      statusBarStyle: "default",
    },
    icons: {
      icon: [
        { url: "/api/icon/32", sizes: "32x32", type: "image/png" },
        { url: "/api/icon/192", sizes: "192x192", type: "image/png" },
        { url: "/api/icon/512", sizes: "512x512", type: "image/png" },
      ],
      apple: [{ url: "/api/icon/180", sizes: "180x180", type: "image/png" }],
      shortcut: "/api/icon/32",
    },
    formatDetection: { telephone: false },
  };
}

export async function generateViewport(): Promise<Viewport> {
  const brand = await getBranding();
  return {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
    viewportFit: "cover",
    themeColor: brand.color,
  };
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const brand = await getBranding();
  return (
    <html lang="pt-BR">
      <body style={brandVars(brand.color) as React.CSSProperties} className="antialiased">
        {children}
        <PwaRegister />
      </body>
    </html>
  );
}
