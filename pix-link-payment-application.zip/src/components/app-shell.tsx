import type { ReactNode } from "react";
import { AppHeader, type HeaderViewer } from "@/components/header";

export function AppShell({
  brand,
  viewer,
  active,
  children,
  title,
  subtitle,
}: {
  brand: { name: string; logoData: string | null };
  viewer: HeaderViewer;
  active: "gerador" | "integracoes" | "aparencia" | "usuarios";
  children: ReactNode;
  title?: string;
  subtitle?: string;
}) {
  return (
    <>
      <AppHeader brand={brand} viewer={viewer} active={active} />
      <main className="mx-auto w-full max-w-3xl px-4 pb-24 pt-[calc(4.75rem+env(safe-area-inset-top))] sm:px-6">
        {title ? (
          <div className="fade-up mb-4">
            <h1 className="text-xl font-extrabold tracking-tight text-slate-900">{title}</h1>
            {subtitle ? <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p> : null}
          </div>
        ) : null}
        {children}
      </main>
    </>
  );
}
