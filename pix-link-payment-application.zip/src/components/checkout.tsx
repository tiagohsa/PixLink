"use client";

import { useEffect, useRef, useState } from "react";
import { BrandMark, Icon } from "@/components/icons";
import { copyToClipboard } from "@/lib/client";
import { formatBrl } from "@/lib/pix";

type Props = {
  id: string;
  brandName: string;
  logoData: string | null;
  amount: number | null;
  summary: string;
  qrDataUrl: string | null;
  payStatus: "none" | "pending" | "paid";
  tracked: boolean;
};

export function Checkout({
  id,
  brandName,
  logoData,
  amount,
  summary,
  qrDataUrl,
  payStatus,
  tracked,
}: Props) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);
  const [copiedLoading, setCopiedLoading] = useState(false);
  const [status, setStatus] = useState<"none" | "pending" | "paid">(payStatus);
  const [pageState, setPageState] = useState<"ok" | "expired" | "notfound">("ok");
  const timer = useRef<number | null>(null);

  useEffect(() => {
    const html = document.documentElement;
    html.classList.add("no-scroll");
    window.scrollTo(0, 0);
    return () => html.classList.remove("no-scroll");
  }, []);

  useEffect(() => {
    if (!tracked || status === "paid") return;
    let cancelled = false;
    async function poll() {
      try {
        const response = await fetch(`/api/links/${id}/status`, { cache: "no-store" });
        const data = (await response.json().catch(() => ({}))) as {
          state?: string;
          payStatus?: string;
        };
        if (cancelled) return;
        if (data.state === "expired") setPageState("expired");
        else if (data.state === "notfound") setPageState("notfound");
        else if (data.payStatus === "paid") setStatus("paid");
        else if (data.payStatus === "pending") setStatus("pending");
      } catch {
        /* mantém o polling silencioso */
      }
    }
    timer.current = window.setInterval(poll, 3500);
    return () => {
      cancelled = true;
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [id, tracked, status]);

  if (pageState === "expired") {
    return <PublicState brandName={brandName} logoData={logoData} title="Este pagamento expirou" message="O prazo deste link terminou. Peça um novo link a quem enviou a cobrança." />;
  }
  if (pageState === "notfound") {
    return <PublicState brandName={brandName} logoData={logoData} title="Pagamento não encontrado" message="Este link não existe ou foi removido." />;
  }

  async function copyEmv() {
    if (copiedLoading) return;
    setCopiedLoading(true);
    setCopyError(null);
    try {
      const response = await fetch(`/api/links/${id}/emv`, { cache: "no-store" });
      const data = (await response.json().catch(() => ({}))) as { emv?: string; error?: string };
      if (!response.ok || !data.emv) {
        if (response.status === 410) setPageState("expired");
        else if (response.status === 409) setStatus("paid");
        else setCopyError(data.error ?? "Não foi possível copiar. Tente novamente.");
        return;
      }
      const ok = await copyToClipboard(data.emv);
      if (ok) {
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2400);
      } else {
        setCopyError("Selecione o resumo do código e copie manualmente.");
      }
    } catch {
      setCopyError("Falha de conexão ao copiar. Tente novamente.");
    } finally {
      setCopiedLoading(false);
    }
  }

  const paid = status === "paid";

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[var(--brand-soft-2)]">
      <div className="mx-auto flex h-full w-full max-w-[400px] min-h-0 flex-1 flex-col px-5 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="flex shrink-0 flex-col items-center pt-1 text-center">
          <div className="flex items-center gap-1.5">
            <BrandMark logoData={logoData} name={brandName} size={22} />
            <span className="text-[13px] font-extrabold tracking-tight text-slate-800">{brandName}</span>
          </div>

          <p className="mt-[clamp(0.65rem,3vh,1.4rem)] text-[clamp(1.9rem,9vw,2.9rem)] font-extrabold leading-none tracking-tight text-slate-900">
            {amount ? formatBrl(amount) : "Pagamento Pix"}
          </p>

          <p className="mt-[clamp(0.35rem,1.6vh,0.75rem)] max-w-[19rem] text-[11px] leading-snug text-slate-500">
            Copie o código e cole no seu aplicativo do banco para pagar.
          </p>

        </div>

        {paid ? (
          <div className="pop-in my-auto flex flex-col items-center justify-center text-center">
            <span className="pop-in flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
              <Icon name="check" size={40} />
            </span>
            <p className="mt-3 text-lg font-extrabold tracking-tight text-slate-900">Pagamento efetuado</p>
            <span className="badge mt-2 bg-emerald-100 text-emerald-700">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Pagamento efetuado
            </span>
            <p className="mt-2 max-w-[16rem] text-xs leading-relaxed text-slate-500">
              O pagamento foi confirmado. Você já pode fechar esta página.
            </p>
          </div>
        ) : (
          <>
            <div className="mx-auto mt-[clamp(0.5rem,2vh,1.1rem)] flex min-h-0 w-full flex-1 items-center justify-center">
              <div className="pop-in flex aspect-square h-full max-h-[min(46vh,260px)] w-auto max-w-full items-center justify-center rounded-[1.4rem] border border-slate-200/70 bg-white p-2.5 shadow-[0_18px_40px_-32px_rgba(15,23,42,0.55)]">
                {qrDataUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={qrDataUrl}
                    alt="QR Code Pix"
                    className="h-full w-full rounded-lg object-contain"
                    draggable={false}
                  />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-2 rounded-lg bg-slate-50 p-3 text-center">
                    <Icon name="qr" size={34} className="text-slate-400" />
                    <p className="text-[11px] text-slate-500">Copie o código Pix abaixo.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="shrink-0 pt-[clamp(0.5rem,2vh,1rem)]">
              <button
                type="button"
                onClick={copyEmv}
                disabled={copiedLoading}
                className="btn btn-primary w-full !py-[clamp(0.75rem,2.2vh,0.95rem)] !text-[15px]"
              >
                <Icon
                  name={copiedLoading ? "spinner" : copied ? "check" : "copy"}
                  size={17}
                  className={copiedLoading ? "animate-spin" : ""}
                />
                {copiedLoading ? "Copiando…" : copied ? "Código copiado" : "Copiar código Pix"}
              </button>
              {copyError ? (
                <p className="mt-1.5 text-center text-[10px] font-medium text-rose-600">{copyError}</p>
              ) : null}

              <div className="mt-2 rounded-xl border border-slate-200/70 bg-white/70 px-3 py-2 text-center">
                <p className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                  Pix copia e cola
                </p>
                <p className="mt-0.5 truncate font-mono text-[10.5px] text-slate-500">{summary}</p>
              </div>

              {tracked ? (
                <div className="mt-2 flex justify-center">
                  <span
                    className={`badge ${
                      paid ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    <span
                      className={`h-1.5 w-1.5 rounded-full ${paid ? "bg-emerald-500" : "bg-amber-500 pulse-dot"}`}
                    />
                    {paid ? "Pagamento efetuado" : "Aguardando pagamento"}
                  </span>
                </div>
              ) : null}
            </div>
          </>
        )}

        <footer className="shrink-0 pb-[max(0.6rem,env(safe-area-inset-bottom))] pt-[clamp(0.5rem,2vh,0.9rem)] text-center text-[10px] font-medium text-slate-400">
          pagamento 100% seguro. ©2026
        </footer>
      </div>
    </div>
  );
}

export function PublicState({
  brandName,
  logoData,
  title,
  message,
}: {
  brandName: string;
  logoData: string | null;
  title: string;
  message: string;
}) {
  useEffect(() => {
    document.documentElement.classList.add("no-scroll");
    return () => document.documentElement.classList.remove("no-scroll");
  }, []);

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[var(--brand-soft-2)]">
      <div className="mx-auto flex h-full w-full max-w-[400px] flex-col px-5 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="flex items-center justify-center gap-1.5 pt-1">
          <BrandMark logoData={logoData} name={brandName} size={22} />
          <span className="text-[13px] font-extrabold tracking-tight text-slate-800">{brandName}</span>
        </div>
        <div className="pop-in my-auto flex flex-col items-center text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-slate-400 shadow-sm">
            <Icon name="alert" size={28} />
          </span>
          <h1 className="mt-3 text-xl font-extrabold tracking-tight text-slate-900">{title}</h1>
          <p className="mt-1.5 max-w-[17rem] text-xs leading-relaxed text-slate-500">{message}</p>
        </div>
        <footer className="pb-[max(0.6rem,env(safe-area-inset-bottom))] text-center text-[10px] font-medium text-slate-400">
          pagamento 100% seguro. ©2026
        </footer>
      </div>
    </div>
  );
}
