"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { BrandMark, Icon, type IconName } from "@/components/icons";
import { formatDateTime } from "@/lib/client";

export type HeaderViewer = {
  name: string;
  username: string;
  role: "master" | "client";
  accessUntil: string | null;
  daysLeft: number | null;
  expired: boolean;
};

type Props = {
  brand: { name: string; logoData: string | null };
  viewer: HeaderViewer;
  active: "gerador" | "integracoes" | "aparencia" | "usuarios";
};

const LINKS: Array<{ key: Props["active"]; href: string; label: string; icon: IconName; master?: boolean }> = [
  { key: "integracoes", href: "/integracoes", label: "Integrações", icon: "plug" },
  { key: "aparencia", href: "/aparencia", label: "Aparência", icon: "palette", master: true },
  { key: "usuarios", href: "/usuarios", label: "Usuários", icon: "users", master: true },
];

export function AppHeader({ brand, viewer, active }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const [installEvent, setInstallEvent] = useState<{ prompt: () => Promise<void> } | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onBeforeInstall(event: Event) {
      event.preventDefault();
      setInstallEvent(event as unknown as { prompt: () => Promise<void> });
    }
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    return () => window.removeEventListener("beforeinstallprompt", onBeforeInstall);
  }, []);

  useEffect(() => {
    function onPointerDown(event: MouseEvent | TouchEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setOpen(false);
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("touchstart", onPointerDown, { passive: true });
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("touchstart", onPointerDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const initials = viewer.name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");

  async function logout() {
    setLeaving(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      /* segue para o login */
    }
    router.replace("/login");
    router.refresh();
  }

  const expiryLabel =
    viewer.role === "master"
      ? "Acesso vitalício"
      : viewer.accessUntil === null
        ? "Acesso sem prazo"
        : viewer.expired
          ? "Acesso expirado"
          : `Expira em ${viewer.daysLeft ?? 0} ${viewer.daysLeft === 1 ? "dia" : "dias"}`;

  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-white/70 bg-white/85 backdrop-blur-xl">
      <div className="safe-top mx-auto flex h-14 w-full max-w-5xl items-center gap-2 px-3 sm:px-5">
        <Link href="/" className="flex min-w-0 flex-1 items-center gap-2.5" aria-label="Ir para o gerador">
          <BrandMark logoData={brand.logoData} name={brand.name} size={32} />
          <span className="truncate text-[15px] font-extrabold tracking-tight text-slate-900">
            {brand.name}
          </span>
        </Link>

        <nav className="flex items-center gap-1.5" aria-label="Navegação principal">
          {LINKS.filter((link) => !link.master || viewer.role === "master").map((link) => (
            <Link
              key={link.key}
              href={link.href}
              aria-label={link.label}
              title={link.label}
              className={`icon-btn ${
                active === link.key
                  ? "!border-[var(--brand)] !bg-[var(--brand-soft)] !text-[var(--brand-dark)]"
                  : ""
              }`}
            >
              <Icon name={link.icon} size={17} />
            </Link>
          ))}
        </nav>

        <div className="relative" ref={menuRef}>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-haspopup="menu"
            aria-expanded={open}
            aria-label="Menu da conta"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--brand)] text-[13px] font-bold text-[var(--brand-contrast)] shadow-sm transition active:scale-95"
          >
            {initials || <Icon name="user" size={16} />}
          </button>

          {open ? (
            <div
              role="menu"
              className="pop-in absolute right-0 top-11 w-[17.5rem] overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-xl shadow-slate-900/10"
            >
              <div className="border-b border-slate-100 bg-[var(--brand-soft-2)] px-4 py-3">
                <p className="truncate text-sm font-bold text-slate-900">{viewer.name}</p>
                <p className="truncate text-xs text-slate-500">@{viewer.username}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="badge bg-white text-[var(--brand-dark)] shadow-sm">
                    {viewer.role === "master" ? "Master" : "Cliente"}
                  </span>
                  <span
                    className={`badge ${
                      viewer.expired
                        ? "bg-rose-100 text-rose-700"
                        : "bg-emerald-100 text-emerald-700"
                    }`}
                  >
                    {expiryLabel}
                  </span>
                </div>
              </div>
              <div className="space-y-1 px-4 py-3 text-xs text-slate-600">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-400">Plano</span>
                  <span className="font-semibold text-slate-700">
                    {viewer.role === "master" ? "Administrador" : "Operador"}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-400">Validade</span>
                  <span className="font-semibold text-slate-700">
                    {viewer.role === "master"
                      ? "Sem prazo"
                      : viewer.accessUntil
                        ? formatDateTime(viewer.accessUntil)
                        : "Sem prazo"}
                  </span>
                </div>
              </div>
              <div className="space-y-1 border-t border-slate-100 p-2">
                {installEvent ? (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={async () => {
                      try {
                        await installEvent.prompt();
                      } finally {
                        setInstallEvent(null);
                        setOpen(false);
                      }
                    }}
                    className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold text-[var(--brand-dark)] transition hover:bg-[var(--brand-soft-2)]"
                  >
                    <Icon name="plus" size={16} />
                    Adicionar à tela inicial
                  </button>
                ) : null}
                <button
                  type="button"
                  role="menuitem"
                  onClick={logout}
                  disabled={leaving}
                  className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold text-rose-600 transition hover:bg-rose-50 disabled:opacity-60"
                >
                  {leaving ? (
                    <Icon name="spinner" size={16} className="animate-spin" />
                  ) : (
                    <Icon name="logout" size={16} />
                  )}
                  {leaving ? "Saindo…" : "Sair"}
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </header>
  );
}
