"use client";

import { useState } from "react";
import { Icon } from "@/components/icons";
import { copyToClipboard, formatDateTime } from "@/lib/client";

type Connected = { provider: string; sandbox: boolean; createdAt: string };

type ProviderMeta = {
  id: string;
  name: string;
  description: string;
  hasSandbox: boolean;
  color: string;
  hint: string;
  fields: Array<{ key: string; label: string; type: "text" | "password"; placeholder: string; optional?: boolean }>;
};

const PROVIDERS_META: ProviderMeta[] = [
  {
    id: "asaas",
    name: "Asaas",
    description: "Cobranças Pix com confirmação automática.",
    hasSandbox: true,
    color: "#0b5cff",
    hint: "Painel Asaas → Integrações → Chave de API. O cliente é criado automaticamente.",
    fields: [
      { key: "apiKey", label: "API key (access_token)", type: "password", placeholder: "$aact_..." },
      { key: "customerId", label: "ID do cliente (opcional)", type: "text", placeholder: "cus_000...", optional: true },
    ],
  },
  {
    id: "mercadopago",
    name: "Mercado Pago",
    description: "Pix com status em tempo real.",
    hasSandbox: false,
    color: "#00a1e0",
    hint: "Suas aplicações → Credenciais → Access Token (APP_USR-).",
    fields: [{ key: "accessToken", label: "Access Token", type: "password", placeholder: "APP_USR-..." }],
  },
  {
    id: "bspay",
    name: "BSPay",
    description: "Cash-in Pix via BSPay.",
    hasSandbox: false,
    color: "#111827",
    hint: "BSPay → API → token Bearer.",
    fields: [{ key: "apiKey", label: "Bearer API key", type: "password", placeholder: "seu_token" }],
  },
  {
    id: "pixup",
    name: "PixUp",
    description: "QR Code Pix dinâmico da PixUp.",
    hasSandbox: false,
    color: "#7c3aed",
    hint: "PixUp → Credenciais da API.",
    fields: [
      { key: "clientId", label: "Client ID", type: "text", placeholder: "client_id" },
      { key: "clientSecret", label: "Client Secret", type: "password", placeholder: "client_secret" },
    ],
  },
];

export function Integrations({ initialConnected }: { initialConnected: Connected[] }) {
  const [connected, setConnected] = useState<Connected[]>(initialConnected);
  const [openProvider, setOpenProvider] = useState<string | null>(null);
  const [forms, setForms] = useState<Record<string, Record<string, string>>>({});
  const [sandbox, setSandbox] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [copiedHook, setCopiedHook] = useState<string | null>(null);

  const origin = typeof window !== "undefined" ? window.location.origin : "";

  function setField(provider: string, field: string, value: string) {
    setForms((current) => ({ ...current, [provider]: { ...(current[provider] ?? {}), [field]: value } }));
  }

  async function save(meta: ProviderMeta) {
    setBusy(meta.id);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch("/api/gateways", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          provider: meta.id,
          credentials: forms[meta.id] ?? {},
          sandbox: Boolean(sandbox[meta.id]),
        }),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Não foi possível salvar as credenciais.");
        return;
      }
      const refreshed = await fetch("/api/gateways", { cache: "no-store" });
      const refreshedData = (await refreshed.json().catch(() => ({}))) as { connected?: Connected[] };
      setConnected(refreshedData.connected ?? connected);
      setForms((current) => ({ ...current, [meta.id]: {} }));
      setOpenProvider(null);
      setNotice(`${meta.name} conectada. Já pode gerar cobranças na aba API.`);
      window.setTimeout(() => setNotice(null), 3200);
    } catch {
      setError("Falha de conexão. Tente novamente.");
    } finally {
      setBusy(null);
    }
  }

  async function disconnect(meta: ProviderMeta) {
    setBusy(meta.id);
    setError(null);
    try {
      const response = await fetch(`/api/gateways?provider=${meta.id}`, { method: "DELETE" });
      if (response.ok) {
        setConnected((current) => current.filter((item) => item.provider !== meta.id));
        setNotice(`${meta.name} desconectada.`);
        window.setTimeout(() => setNotice(null), 2600);
      } else {
        setError("Não foi possível desconectar.");
      }
    } catch {
      setError("Falha de conexão.");
    } finally {
      setBusy(null);
    }
  }

  async function copyHook(provider: string) {
    await copyToClipboard(`${origin}/api/hooks/${provider}`);
    setCopiedHook(provider);
    window.setTimeout(() => setCopiedHook((value) => (value === provider ? null : value)), 1800);
  }

  return (
    <div className="space-y-3">
      {notice ? (
        <div className="fade-up flex items-center gap-2 rounded-xl border border-[var(--brand-ring)] bg-[var(--brand-soft-2)] px-3 py-2.5 text-sm font-semibold text-[var(--brand-dark)]">
          <Icon name="check" size={15} />
          {notice}
        </div>
      ) : null}
      {error ? (
        <div className="fade-up flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2.5 text-sm text-rose-700">
          <Icon name="alert" size={15} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      ) : null}

      {PROVIDERS_META.map((meta) => {
        const connection = connected.find((item) => item.provider === meta.id);
        const isOpen = openProvider === meta.id;
        const form = forms[meta.id] ?? {};
        return (
          <section key={meta.id} className="fade-up card overflow-hidden">
            <div className="flex items-center gap-3 p-4">
              <span
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-extrabold text-white"
                style={{ backgroundColor: meta.color }}
              >
                {meta.name.slice(0, 2).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="truncate text-sm font-bold text-slate-900">{meta.name}</h2>
                  {connection ? (
                    <span className="badge bg-emerald-100 text-emerald-700">
                      <Icon name="check" size={10} />
                      Conectada
                    </span>
                  ) : (
                    <span className="badge bg-slate-100 text-slate-500">Não conectada</span>
                  )}
                  {connection?.sandbox ? (
                    <span className="badge bg-amber-100 text-amber-700">sandbox</span>
                  ) : null}
                </div>
                <p className="truncate text-xs text-slate-500">{meta.description}</p>
                {connection ? (
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    Conectada em {formatDateTime(connection.createdAt)} · suas chaves, uso privado
                  </p>
                ) : null}
              </div>
              <button
                type="button"
                onClick={() => {
                  setOpenProvider(isOpen ? null : meta.id);
                  setSandbox((current) => ({ ...current, [meta.id]: connection?.sandbox ?? false }));
                }}
                className={`btn ${connection ? "btn-ghost" : "btn-soft"} !px-3 !py-2 !text-xs`}
                aria-expanded={isOpen}
              >
                <Icon name={isOpen ? "x" : connection ? "refresh" : "plus"} size={14} />
                {isOpen ? "Fechar" : connection ? "Atualizar" : "Conectar"}
              </button>
            </div>

            {isOpen ? (
              <div className="fade-up space-y-3 border-t border-slate-100 bg-slate-50/60 p-4">
                <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-500">
                  <Icon name="info" size={12} className="mt-0.5 shrink-0" />
                  {meta.hint}
                </p>
                {meta.fields.map((field) => (
                  <div key={field.key}>
                    <label
                      htmlFor={`${meta.id}-${field.key}`}
                      className="mb-1 block text-xs font-semibold text-slate-600"
                    >
                      {field.label}
                    </label>
                    <div className="relative">
                      <input
                        id={`${meta.id}-${field.key}`}
                        className="field pr-11 font-mono text-[13px]"
                        type={
                          field.type === "password" && !showSecrets[`${meta.id}-${field.key}`]
                            ? "password"
                            : "text"
                        }
                        placeholder={field.placeholder}
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck={false}
                        value={form[field.key] ?? ""}
                        onChange={(event) => setField(meta.id, field.key, event.target.value)}
                      />
                      {field.type === "password" ? (
                        <button
                          type="button"
                          aria-label="Mostrar credencial"
                          onClick={() =>
                            setShowSecrets((current) => ({
                              ...current,
                              [`${meta.id}-${field.key}`]: !current[`${meta.id}-${field.key}`],
                            }))
                          }
                          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-slate-400 hover:bg-slate-100"
                        >
                          <Icon
                            name={showSecrets[`${meta.id}-${field.key}`] ? "eyeOff" : "eye"}
                            size={16}
                          />
                        </button>
                      ) : null}
                    </div>
                  </div>
                ))}

                {meta.hasSandbox ? (
                  <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2.5">
                    <span className="text-xs font-semibold text-slate-700">Usar ambiente sandbox</span>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={Boolean(sandbox[meta.id])}
                      onClick={() => setSandbox((current) => ({ ...current, [meta.id]: !current[meta.id] }))}
                      className={`relative h-6 w-11 rounded-full transition ${
                        sandbox[meta.id] ? "bg-[var(--brand)]" : "bg-slate-300"
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
                          sandbox[meta.id] ? "left-[1.375rem]" : "left-0.5"
                        }`}
                      />
                    </button>
                  </label>
                ) : null}

                <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5">
                  <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                    URL de webhook
                  </p>
                  <div className="mt-1 flex items-center gap-2">
                    <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-slate-600">
                      {origin}/api/hooks/{meta.id}
                    </code>
                    <button
                      type="button"
                      onClick={() => void copyHook(meta.id)}
                      className="icon-btn !h-7 !w-7"
                      aria-label="Copiar URL do webhook"
                    >
                      <Icon name={copiedHook === meta.id ? "check" : "copy"} size={13} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => void save(meta)}
                    disabled={busy === meta.id}
                    className="btn btn-primary !py-2.5 !text-xs"
                  >
                    {busy === meta.id ? (
                      <Icon name="spinner" size={14} className="animate-spin" />
                    ) : (
                      <Icon name="check" size={14} />
                    )}
                    {connection ? "Salvar alterações" : "Conectar API"}
                  </button>
                  {connection ? (
                    <button
                      type="button"
                      onClick={() => void disconnect(meta)}
                      disabled={busy === meta.id}
                      className="btn btn-ghost !py-2.5 !text-xs !text-rose-600"
                    >
                      <Icon name="trash" size={14} />
                      Desconectar
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setOpenProvider(null)}
                      className="btn btn-ghost !py-2.5 !text-xs"
                    >
                      Cancelar
                    </button>
                  )}
                </div>
              </div>
            ) : null}
          </section>
        );
      })}

      <div className="card flex items-start gap-2.5 p-4">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--brand-soft)] text-[var(--brand-dark)]">
          <Icon name="shield" size={16} />
        </span>
        <p className="text-[11px] leading-relaxed text-slate-500">
          Cada operador conecta as próprias chaves. As credenciais ficam salvas apenas para a sua conta e
          nunca são exibidas por completo. Os webhooks atualizam o status dos links de API para{" "}
          <strong className="text-slate-700">pago</strong> automaticamente.
        </p>
      </div>
    </div>
  );
}
