"use client";

import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { BrandMark, Icon } from "@/components/icons";

type Branding = {
  name: string;
  logoData: string | null;
  iconData: string | null;
  faviconData: string | null;
  color: string;
};

const COLORS = ["#0f9d76", "#2563eb", "#7c3aed", "#db2777", "#ea580c", "#0f766e", "#111827", "#0891b2"];
const MAX_BYTES = 420_000;

function hexToRgb(hex: string): [number, number, number] {
  const clean = /^#[0-9a-f]{6}$/i.test(hex) ? hex.slice(1) : "0f9d76";
  return [parseInt(clean.slice(0, 2), 16), parseInt(clean.slice(2, 4), 16), parseInt(clean.slice(4, 6), 16)];
}

function mix(hex: string, weight: number): string {
  const [r, g, b] = hexToRgb(hex);
  const channel = (value: number) => Math.round(value + (255 - value) * weight);
  return `#${[channel(r), channel(g), channel(b)].map((c) => c.toString(16).padStart(2, "0")).join("")}`;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Não foi possível ler o arquivo."));
    reader.readAsDataURL(file);
  });
}

export function AppearanceForm({ initial }: { initial: Branding }) {
  const router = useRouter();
  const [name, setName] = useState(initial.name);
  const [color, setColor] = useState(initial.color);
  const [logoData, setLogoData] = useState<string | null>(initial.logoData);
  const [iconData, setIconData] = useState<string | null>(initial.iconData);
  const [faviconData, setFaviconData] = useState<string | null>(initial.faviconData);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const logoInput = useRef<HTMLInputElement>(null);
  const iconInput = useRef<HTMLInputElement>(null);
  const faviconInput = useRef<HTMLInputElement>(null);

  const previewStyle = {
    "--brand": color,
    "--brand-dark": mix(color, 0),
    "--brand-soft": mix(color, 0.88),
    "--brand-soft-2": mix(color, 0.94),
    "--brand-ring": mix(color, 0.55),
  } as React.CSSProperties;

  async function pick(file: File | undefined, target: "logo" | "icon" | "favicon") {
    setError(null);
    if (!file) return;
    if (!/^image\/(png|jpeg|webp|svg\+xml)$/.test(file.type)) {
      setError("Use uma imagem PNG, JPG, WEBP ou SVG.");
      return;
    }
    if (file.size > MAX_BYTES) {
      setError("Imagem muito grande. Use até ~400 KB.");
      return;
    }
    try {
      const dataUrl = await readFileAsDataUrl(file);
      if (target === "logo") setLogoData(dataUrl);
      else if (target === "icon") setIconData(dataUrl);
      else setFaviconData(dataUrl);
    } catch {
      setError("Não foi possível carregar a imagem.");
    }
  }

  async function save() {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch("/api/branding", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, color, logoData, iconData, faviconData }),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Não foi possível salvar.");
        return;
      }
      setNotice("Aparência atualizada. O PWA usará o novo nome e ícone quando instalado.");
      router.refresh();
      window.setTimeout(() => setNotice(null), 3600);
    } catch {
      setError("Falha de conexão. Tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  const uploads: Array<{
    key: "logo" | "icon" | "favicon";
    label: string;
    value: string | null;
    ref: React.RefObject<HTMLInputElement | null>;
    hint: string;
  }> = [
    { key: "logo", label: "Logo", value: logoData, ref: logoInput, hint: "Header e checkout" },
    { key: "favicon", label: "Favicon", value: faviconData, ref: faviconInput, hint: "Padrão: igual à logo" },
    { key: "icon", label: "Ícone do app 512", value: iconData, ref: iconInput, hint: "Add to Home Screen" },
  ];

  return (
    <div className="space-y-3">
      <div className="fade-up card space-y-4 p-4 sm:p-5">
        <div>
          <label htmlFor="system-name" className="mb-1.5 block text-sm font-semibold text-slate-700">
            Nome do sistema
          </label>
          <input
            id="system-name"
            className="field"
            value={name}
            maxLength={40}
            onChange={(event) => setName(event.target.value)}
            placeholder="PIX LINK"
          />
          <p className="mt-1 text-[11px] text-slate-500">Aparece no header, no login, no PWA e no checkout.</p>
        </div>

        <div>
          <span className="mb-1.5 block text-sm font-semibold text-slate-700">Cor do sistema</span>
          <div className="flex flex-wrap items-center gap-2">
            {COLORS.map((swatch) => (
              <button
                key={swatch}
                type="button"
                onClick={() => setColor(swatch)}
                aria-label={`Cor ${swatch}`}
                className={`h-9 w-9 rounded-xl transition ${
                  color.toLowerCase() === swatch.toLowerCase()
                    ? "ring-2 ring-slate-900 ring-offset-2"
                    : "ring-1 ring-black/5"
                }`}
                style={{ backgroundColor: swatch }}
              />
            ))}
            <label className="chip !py-2">
              <Icon name="palette" size={13} />
              Outra
              <input
                type="color"
                value={color}
                onChange={(event) => setColor(event.target.value)}
                className="h-5 w-6 cursor-pointer border-0 bg-transparent p-0"
              />
            </label>
          </div>
          <p className="mt-1.5 text-[11px] text-slate-500">
            Altera botões, destaques e o fundo mint do tema — inclusive na tela pública de pagamento.
          </p>
        </div>

        <div className="space-y-2">
          <span className="block text-sm font-semibold text-slate-700">Imagens</span>
          {uploads.map((item) => (
            <div key={item.key} className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-2.5">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-50">
                {item.value ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.value} alt={item.label} className="h-full w-full object-contain" />
                ) : (
                  <Icon name="image" size={18} className="text-slate-300" />
                )}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-slate-800">{item.label}</p>
                <p className="text-[10px] text-slate-400">{item.hint}</p>
              </div>
              <input
                ref={item.ref}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                className="hidden"
                onChange={(event) => void pick(event.target.files?.[0], item.key)}
              />
              <button
                type="button"
                onClick={() => item.ref.current?.click()}
                className="btn btn-soft !px-2.5 !py-1.5 !text-[11px]"
              >
                <Icon name="upload" size={12} />
                Enviar
              </button>
              {item.value ? (
                <button
                  type="button"
                  aria-label={`Remover ${item.label}`}
                  onClick={() => {
                    if (item.key === "logo") setLogoData(null);
                    else if (item.key === "icon") setIconData(null);
                    else setFaviconData(null);
                  }}
                  className="icon-btn !h-7 !w-7 !text-rose-500"
                >
                  <Icon name="trash" size={12} />
                </button>
              ) : null}
            </div>
          ))}
          <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-500">
            <Icon name="info" size={12} className="mt-0.5 shrink-0" />
            Sem upload, o favicon e o ícone do PWA usam a logo. Formatos: PNG, JPG, WEBP ou SVG (até 400 KB).
          </p>
        </div>

        {error ? (
          <div className="fade-up flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2.5 text-sm text-rose-700">
            <Icon name="alert" size={15} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}
        {notice ? (
          <div className="fade-up flex items-start gap-2 rounded-xl border border-[var(--brand-ring)] bg-[var(--brand-soft-2)] px-3 py-2.5 text-xs font-semibold text-[var(--brand-dark)]">
            <Icon name="check" size={14} className="mt-0.5 shrink-0" />
            <span>{notice}</span>
          </div>
        ) : null}

        <button type="button" onClick={save} disabled={busy} className="btn btn-primary w-full !py-3">
          {busy ? <Icon name="spinner" size={17} className="animate-spin" /> : <Icon name="check" size={17} />}
          {busy ? "Salvando…" : "Salvar aparência"}
        </button>
      </div>

      <div className="fade-up card overflow-hidden" style={previewStyle}>
        <div className="border-b border-slate-100 px-4 py-2.5">
          <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Pré-visualização</p>
        </div>
        <div className="bg-[var(--brand-soft-2)] p-4">
          <div className="mx-auto flex max-w-[280px] flex-col items-center rounded-2xl border border-slate-200/70 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-1.5">
              <BrandMark logoData={logoData} name={name || "PIX LINK"} size={20} />
              <span className="text-[11px] font-extrabold text-slate-800">{name || "PIX LINK"}</span>
            </div>
            <p className="mt-3 text-2xl font-extrabold tracking-tight text-slate-900">R$ 50,00</p>
            <p className="mt-1 text-center text-[9px] leading-snug text-slate-500">
              Copie o código e cole no seu aplicativo do banco.
            </p>
            <div className="mt-3 flex h-20 w-20 items-center justify-center rounded-xl border border-slate-200 bg-slate-50">
              <Icon name="qr" size={30} className="text-slate-300" />
            </div>
            <button type="button" className="btn btn-primary mt-3 w-full !py-2 !text-[11px]">
              <Icon name="copy" size={12} />
              Copiar código Pix
            </button>
            <p className="mt-2 text-[8px] text-slate-400">pagamento 100% seguro. ©2026</p>
          </div>
        </div>
      </div>
    </div>
  );
}
