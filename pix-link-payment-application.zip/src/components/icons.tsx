import type { SVGProps } from "react";

export type IconName =
  | "link"
  | "plug"
  | "palette"
  | "users"
  | "copy"
  | "check"
  | "trash"
  | "refresh"
  | "logout"
  | "plus"
  | "x"
  | "eye"
  | "eyeOff"
  | "star"
  | "qr"
  | "key"
  | "code"
  | "wallet"
  | "chevronDown"
  | "external"
  | "spinner"
  | "clock"
  | "sparkles"
  | "arrowLeft"
  | "alert"
  | "shield"
  | "lock"
  | "upload"
  | "image"
  | "info"
  | "history"
  | "zap"
  | "user";

const PATHS: Record<IconName, string> = {
  link: "M9.5 14.5 14.5 9.5M7.7 17.3l-1.4 1.4a3.6 3.6 0 0 1-5.1-5.1l3.2-3.2a3.6 3.6 0 0 1 5.1 0M16.3 6.7l1.4-1.4a3.6 3.6 0 0 1 5.1 5.1l-3.2 3.2a3.6 3.6 0 0 1-5.1 0",
  plug: "M9 7V3m6 4V3M7 7h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5V7Zm5 9v5",
  palette:
    "M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H13a2 2 0 0 1 0-4h4.5A3.5 3.5 0 0 0 21 8.5V8a5 5 0 0 0-5-5h-4Zm-5.5 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm3-3a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm-4 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
  users:
    "M16 19v-1.5a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V19M9 9.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm13 9.5v-1.5a4 4 0 0 0-3-3.9M16 2.6a3.5 3.5 0 0 1 0 6.8",
  copy: "M9 9V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-4M5 9h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z",
  check: "m4 12.5 5 5L20 6.5",
  trash: "M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v6m4-6v6",
  refresh: "M21 12a9 9 0 1 1-3.2-6.9M21 3v6h-6",
  logout: "M15 17l5-5-5-5M20 12H9M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6",
  plus: "M12 5v14M5 12h14",
  x: "M6 6l12 12M18 6 6 18",
  eye: "M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Zm10 2.6a2.6 2.6 0 1 0 0-5.2 2.6 2.6 0 0 0 0 5.2Z",
  eyeOff: "M3 3l18 18M10.6 6.1A9.6 9.6 0 0 1 12 6c6.4 0 10 6 10 6a17 17 0 0 1-2.2 3M6.5 7.9A16.5 16.5 0 0 0 2 12s3.6 6 10 6a9.8 9.8 0 0 0 4.1-.9M9.9 9.9a3 3 0 0 0 4.2 4.2",
  star: "m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2-5.5-2.9-5.5 2.9 1-6.2L3 9.6l6.2-.9L12 3Z",
  qr: "M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 3h3v3h-3v-3Zm3-3h3v3",
  key: "M15 8.5a3.5 3.5 0 1 0-3.4 3.5L9 14.6V17H6.5v2.5H4V22H2v-3.5l6.5-6.5A3.5 3.5 0 0 0 15 8.5Z",
  code: "m9 8-5 4 5 4m6-8 5 4-5 4",
  wallet: "M3 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2m-16 0v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3m0-6h-4a2.5 2.5 0 0 0 0 5h4v-2m0 2v-5",
  chevronDown: "m6 9 6 6 6-6",
  external: "M14 4h6v6m0-6-8 8M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5",
  spinner: "M21 12a9 9 0 1 1-9-9",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13v5l3.5 2",
  sparkles: "M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6L12 3Zm7 11 .9 2.4 2.1.9-2.1.9-.9 2.4-.9-2.4L16 17l2.1-.6.9-2.4Z",
  arrowLeft: "M19 12H5m6-7-7 7 7 7",
  alert: "M12 9v4m0 3h.01M10.3 3.9 2.5 18a2 2 0 0 0 1.8 3h15.4a2 2 0 0 0 1.8-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
  shield: "M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10Zm-3-10 2.2 2.2L15.5 10",
  lock: "M6 11h12v10H6V11Zm3 0V7a3 3 0 0 1 6 0v4",
  upload: "M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3",
  image: "M4 5h16v14H4V5Zm3 9 3-3 4 4m2-2 1.5 1.5M8.5 9.5h.01",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13h.01M11 12h1v5h1",
  history: "M3 12a9 9 0 1 0 3-6.7M3 4v5h5M12 8v4.5l3 1.8",
  zap: "M13 2 4.5 13.5H11l-1 8.5L19.5 10H13V2Z",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-8 9v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1",
};

export function Icon({
  name,
  size = 18,
  className,
  ...rest
}: { name: IconName; size?: number } & SVGProps<SVGSVGElement>) {
  const filled = name === "zap" || name === "star";
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
      {...rest}
    >
      <path d={PATHS[name]} />
    </svg>
  );
}

export function BrandMark({
  logoData,
  name,
  size = 36,
  rounded = true,
}: {
  logoData: string | null;
  name: string;
  size?: number;
  rounded?: boolean;
}) {
  if (logoData) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={logoData}
        alt={name}
        width={size}
        height={size}
        style={{ width: size, height: size }}
        className={`${rounded ? "rounded-xl" : ""} object-contain`}
      />
    );
  }
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
  return (
    <span
      aria-label={name}
      style={{ width: size, height: size, fontSize: Math.max(12, size * 0.4) }}
      className={`inline-flex items-center justify-center font-extrabold tracking-tight ${
        rounded ? "rounded-xl" : ""
      } bg-[var(--brand)] text-[var(--brand-contrast)]`}
    >
      {initials || "PX"}
    </span>
  );
}
