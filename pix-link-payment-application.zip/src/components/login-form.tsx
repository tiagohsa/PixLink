"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";
import { postJson } from "@/lib/client";

export function LoginForm() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (loading) return;
    setError(null);
    if (!username.trim() || !password) {
      setError("Preencha usuário e senha para entrar.");
      return;
    }
    setLoading(true);
    try {
      const { ok, data } = await postJson<{ ok?: boolean }>("/api/auth/login", {
        username: username.trim(),
        password,
      });
      if (!ok) {
        setError(data.error || "Não foi possível entrar. Tente novamente.");
        setLoading(false);
        return;
      }
      router.replace("/");
      router.refresh();
    } catch {
      setError("Falha de conexão. Tente novamente.");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="mt-6 space-y-4">
      <div>
        <label htmlFor="username" className="mb-1.5 block text-sm font-semibold text-slate-700">
          Usuário
        </label>
        <div className="relative">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
            <Icon name="user" size={18} />
          </span>
          <input
            id="username"
            name="username"
            type="text"
            inputMode="text"
            autoCapitalize="none"
            autoCorrect="off"
            autoComplete="username"
            spellCheck={false}
            placeholder="Seu usuário"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            className="field pl-11"
            required
          />
          {username ? (
            <button
              type="button"
              onClick={() => setUsername("")}
              aria-label="Limpar usuário"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
            >
              <Icon name="x" size={15} />
            </button>
          ) : null}
        </div>
      </div>

      <div>
        <label htmlFor="password" className="mb-1.5 block text-sm font-semibold text-slate-700">
          Senha
        </label>
        <div className="relative">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
            <Icon name="lock" size={18} />
          </span>
          <input
            id="password"
            name="password"
            type={showPassword ? "text" : "password"}
            autoComplete="current-password"
            placeholder="Sua senha"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="field pl-11 pr-12"
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword((value) => !value)}
            aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
          >
            <Icon name={showPassword ? "eyeOff" : "eye"} size={17} />
          </button>
        </div>
      </div>

      {error ? (
        <div className="fade-up flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-sm text-rose-700">
          <Icon name="alert" size={17} className="mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="font-medium">{error}</p>
            <button
              type="button"
              onClick={() => {
                setError(null);
                setLoading(false);
              }}
              className="text-xs font-bold text-rose-700 underline underline-offset-2"
            >
              Ir para o login
            </button>
          </div>
        </div>
      ) : null}

      <button type="submit" disabled={loading} className="btn btn-primary w-full py-3 text-base">
        {loading ? (
          <>
            <Icon name="spinner" size={18} className="animate-spin" />
            Entrando…
          </>
        ) : (
          <>
            Entrar
            <Icon name="arrowLeft" size={18} className="rotate-180" />
          </>
        )}
      </button>
      <p className="text-center text-xs leading-relaxed text-slate-500">
        Acesso exclusivo para operadores autorizados.
        <br />
        Esqueceu a senha? Fale com o administrador da conta.
      </p>
    </form>
  );
}
