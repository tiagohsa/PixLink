"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";
import { copyToClipboard, formatDateTime, postJson, readClipboard, shortUrl } from "@/lib/client";
import type { LinkDTO } from "@/lib/links";
import { detectPixKeyLabel, formatBrl, normalizeAmountInput, summarizePixEmv } from "@/lib/pix";

type Gateway = { provider: string; sandbox: boolean; name: string };
type Presets = { pixKeys: string[]; amounts: string[] };
type Tab = "key" | "copy" | "api";
type Inspection = {
  valid: boolean;
  errors: string[];
  warnings: string[];
  amount: number | null;
  remoteChecked: boolean;
  keyHint: string;
  summary: string;
};

const QUICK_AMOUNTS = ["10", "20", "50", "100", "250"];

export function Generator({
  initialLinks,
  initialPresets,
  gateways,
}: {
  initialLinks: LinkDTO[];
  initialPresets: Presets;
  gateways: Gateway[];
}) {
  const [tab, setTab] = useState<Tab>("key");
  const [key, setKey] = useState("");
  const [amount, setAmount] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [recipientCity, setRecipientCity] = useState("");
  const [validityValue, setValidityValue] = useState("");
  const [validityUnit, setValidityUnit] = useState<"minutes" | "hours">("hours");
  const [description, setDescription] = useState("");
  const [advanced, setAdvanced] = useState(false);

  const [emv, setEmv] = useState("");
  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [inspecting, setInspecting] = useState(false);

  const [provider, setProvider] = useState<string>(gateways[0]?.provider ?? "");

  const [presets, setPresets] = useState<Presets>(initialPresets);
  const [links, setLinks] = useState<LinkDTO[]>(initialLinks);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [result, setResult] = useState<LinkDTO | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const detectedLabel = key.trim() ? detectPixKeyLabel(key) : null;
  const parsedAmount = normalizeAmountInput(amount);

  const flashCopied = useCallback((id: string) => {
    setCopied(id);
    window.setTimeout(() => setCopied((current) => (current === id ? null : current)), 1800);
  }, []);

  async function handleCopy(text: string, id: string) {
    const ok = await copyToClipboard(text);
    if (ok) flashCopied(id);
    else setError("Não foi possível copiar automaticamente. Selecione o texto e copie manualmente.");
  }

  const inspectEmv = useCallback(async (value: string) => {
    const clean = value.trim();
    if (clean.length < 20) {
      setInspection(null);
      return;
    }
    setInspecting(true);
    try {
      const { ok, data } = await postJson<Inspection>("/api/pix/inspect", { emv: clean });
      if (ok) setInspection(data);
      else setInspection(null);
    } catch {
      setInspection(null);
    } finally {
      setInspecting(false);
    }
  }, []);

  useEffect(() => {
    if (tab !== "copy") return;
    const clean = emv.trim();
    if (clean.length < 20) {
      setInspection(null);
      return;
    }
    const timer = window.setTimeout(() => void inspectEmv(clean), 450);
    return () => window.clearTimeout(timer);
  }, [emv, tab, inspectEmv]);

  async function pasteFromClipboard() {
    const text = await readClipboard();
    if (text) {
      setEmv(text.trim());
      setError(null);
      void inspectEmv(text);
    } else {
      setNotice("Seu navegador bloqueou o acesso à área de transferência. Toque e segure no campo e escolha “Colar”.");
    }
  }

  async function updatePresets(kind: "key" | "amount", action: "add" | "remove", value: string) {
    const { ok, data } = await postJson<Presets>("/api/presets", { kind, action, value });
    if (!ok) {
      setError((data as { error?: string }).error ?? "Não foi possível salvar o preset.");
      return;
    }
    setPresets({ pixKeys: data.pixKeys ?? [], amounts: data.amounts ?? [] });
    setNotice(action === "add" ? "Predefinição salva." : "Predefinição removida.");
    window.setTimeout(() => setNotice(null), 2200);
  }

  async function generate() {
    if (busy) return;
    setError(null);
    setNotice(null);
    setBusy(true);
    setResult(null);
    try {
      if (tab === "copy") {
        const clean = emv.trim();
        if (!clean) {
          setError("Cole o código Pix copia e cola.");
          setBusy(false);
          return;
        }
        const { ok, data } = await postJson<{ link: LinkDTO }>("/api/links", { kind: "copy", emv: clean, description });
        if (!ok || !data.link) {
          setError((data as { error?: string }).error ?? "Não foi possível gerar o link.");
          setBusy(false);
          return;
        }
        setResult(data.link);
        setLinks((current) => [data.link, ...current]);
      } else if (tab === "api") {
        if (!provider) {
          setError("Conecte uma API em Integrações para gerar cobranças rastreadas.");
          setBusy(false);
          return;
        }
        if (!parsedAmount) {
          setError("Informe o valor da cobrança.");
          setBusy(false);
          return;
        }
        const { ok, data } = await postJson<{ link: LinkDTO }>("/api/links/api", {
          provider,
          amount: parsedAmount,
          description,
        });
        if (!ok || !data.link) {
          setError((data as { error?: string }).error ?? "O provedor não retornou o Pix. Tente novamente.");
          setBusy(false);
          return;
        }
        setResult(data.link);
        setLinks((current) => [data.link, ...current]);
      } else {
        if (!key.trim()) {
          setError("Informe a chave Pix.");
          setBusy(false);
          return;
        }
        const { ok, data } = await postJson<{ link: LinkDTO }>("/api/links", {
          kind: "key",
          key: key.trim(),
          amount: parsedAmount,
          recipientName,
          recipientCity,
          description,
          validityValue: validityValue ? Number(validityValue) : null,
          validityUnit,
        });
        if (!ok || !data.link) {
          setError((data as { error?: string }).error ?? "Não foi possível gerar o link.");
          setBusy(false);
          return;
        }
        setResult(data.link);
        setLinks((current) => [data.link, ...current]);
      }
      window.setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 60);
    } catch {
      setError("Falha de conexão. Tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  async function removeLink(id: string) {
    const response = await fetch(`/api/links/${id}`, { method: "DELETE" });
    if (response.ok) {
      setLinks((current) => current.filter((item) => item.id !== id));
      if (result?.id === id) setResult(null);
      setPendingDelete(null);
      setNotice("Link excluído.");
      window.setTimeout(() => setNotice(null), 2000);
    } else {
      setError("Não foi possível excluir o link.");
    }
  }

  async function refreshStatus(id: string) {
    const response = await fetch(`/api/links/${id}/status`, { cache: "no-store" });
    const data = (await response.json().catch(() => ({}))) as { payStatus?: string };
    if (response.ok && data.payStatus) {
      setLinks((current) =>
        current.map((item) =>
          item.id === id
            ? { ...item, payStatus: data.payStatus === "paid" ? "paid" : "pending" }
            : item,
        ),
      );
    }
  }

  function reuse(link: LinkDTO) {
    setError(null);
    setResult(null);
    if (link.kind === "copy") {
      setTab("copy");
      setEmv(link.emv);
      setInspection(null);
      void inspectEmv(link.emv);
    } else if (link.kind === "api") {
      setTab("api");
      setProvider(link.provider ?? provider);
      setAmount(link.amount ? link.amount.toFixed(2) : "");
      setDescription(link.description ?? "");
    } else {
      setTab("key");
      setKey(link.keyRaw ?? "");
      setAmount(link.amount ? link.amount.toFixed(2) : "");
      setDescription(link.description ?? "");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const amountChips = Array.from(
    new Set([
      ...QUICK_AMOUNTS.map((value) => Number(value).toFixed(2)),
      ...presets.amounts
        .map((value) => normalizeAmountInput(value)?.toFixed(2))
        .filter((value): value is string => Boolean(value)),
    ]),
  );

  return (
    <div className="space-y-4">
      <div className="fade-up card overflow-hidden">
        <div className="border-b border-slate-100 bg-white/70 p-2">
          <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-100/70 p-1">
            {[
              { id: "key" as Tab, label: "Chave Pix", icon: "key" as const },
              { id: "copy" as Tab, label: "Copia e cola", icon: "code" as const },
              { id: "api" as Tab, label: "API", icon: "zap" as const },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setError(null);
                  setResult(null);
                }}
                className={`flex items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-[13px] font-bold transition ${
                  tab === item.id
                    ? "bg-white text-[var(--brand-dark)] shadow-sm"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                <Icon name={item.icon} size={15} />
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4 p-4 sm:p-5">
          {result ? (
            <div ref={resultRef} className="pop-in rounded-2xl border border-[var(--brand-ring)] bg-[var(--brand-soft-2)] p-4">
              <div className="flex items-center gap-2 text-sm font-bold text-[var(--brand-dark)]">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[var(--brand)] text-[var(--brand-contrast)]">
                  <Icon name="check" size={14} />
                </span>
                Link de pagamento criado
              </div>
              <p className="mt-2 text-2xl font-extrabold tracking-tight text-slate-900">
                {result.amount ? formatBrl(result.amount) : "Valor livre"}
              </p>
              <div className="mt-3 flex items-center gap-2 rounded-xl border border-white bg-white px-3 py-2.5 shadow-sm">
                <Icon name="link" size={16} className="shrink-0 text-[var(--brand-dark)]" />
                <span className="min-w-0 flex-1 truncate font-mono text-[13px] text-slate-700">
                  {shortUrl(result.id).replace(/^https?:\/\//, "")}
                </span>
                <button
                  type="button"
                  onClick={() => handleCopy(shortUrl(result.id), `result-${result.id}`)}
                  className="btn btn-soft !px-2.5 !py-1.5 !text-xs"
                >
                  <Icon name={copied === `result-${result.id}` ? "check" : "copy"} size={14} />
                  {copied === `result-${result.id}` ? "Copiado" : "Copiar"}
                </button>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <a
                  href={shortUrl(result.id)}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary !py-2.5 !text-sm"
                >
                  <Icon name="external" size={15} />
                  Abrir página do cliente
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setResult(null);
                    setNotice("Pronto para gerar outro link.");
                    window.setTimeout(() => setNotice(null), 1800);
                  }}
                  className="btn btn-ghost !py-2.5 !text-sm"
                >
                  <Icon name="plus" size={15} />
                  Novo link
                </button>
              </div>
              {result.kind === "key" && result.expiresAt ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
                  <Icon name="clock" size={12} />
                  Expira em {formatDateTime(result.expiresAt)}
                </p>
              ) : null}
              {result.kind === "copy" ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
                  <Icon name="info" size={12} />
                  Links de copia e cola não expiram.
                </p>
              ) : null}
            </div>
          ) : null}

          {tab === "key" ? (
            <>
              <div>
                <label htmlFor="pix-key" className="mb-1.5 block text-sm font-semibold text-slate-700">
                  Chave Pix
                </label>
                <div className="relative">
                  <input
                    id="pix-key"
                    className="field pr-24"
                    placeholder="CPF, CNPJ, e-mail, celular ou aleatória"
                    value={key}
                    inputMode="text"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    onChange={(event) => setKey(event.target.value)}
                  />
                  <div className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1">
                    {detectedLabel ? (
                      <span className="badge bg-[var(--brand-soft)] text-[var(--brand-dark)]">{detectedLabel}</span>
                    ) : null}
                    {key ? (
                      <button
                        type="button"
                        onClick={() => setKey("")}
                        aria-label="Apagar chave"
                        className="rounded-full p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                      >
                        <Icon name="x" size={15} />
                      </button>
                    ) : null}
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Salvas</span>
                  {presets.pixKeys.length === 0 ? (
                    <span className="text-[11px] text-slate-400">nenhuma ainda</span>
                  ) : (
                    presets.pixKeys.map((savedKey) => (
                      <span key={savedKey} className="chip !py-1 !text-[11px]">
                        <button type="button" onClick={() => setKey(savedKey)} className="max-w-[9rem] truncate">
                          {savedKey}
                        </button>
                        <button
                          type="button"
                          aria-label="Remover chave salva"
                          onClick={() => void updatePresets("key", "remove", savedKey)}
                          className="text-slate-400 transition hover:text-rose-500"
                        >
                          <Icon name="x" size={11} />
                        </button>
                      </span>
                    ))
                  )}
                  <button
                    type="button"
                    disabled={!key.trim() || presets.pixKeys.includes(key.trim())}
                    onClick={() => void updatePresets("key", "add", key.trim())}
                    className="chip !border-dashed !py-1 !text-[11px] disabled:opacity-40"
                  >
                    <Icon name="star" size={11} />
                    Salvar chave
                  </button>
                </div>
              </div>
            </>
          ) : null}

          {tab === "copy" ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="emv" className="text-sm font-semibold text-slate-700">
                  Código Pix copia e cola
                </label>
                <button type="button" onClick={pasteFromClipboard} className="btn btn-soft !px-3 !py-1.5 !text-xs">
                  <Icon name="copy" size={13} />
                  Colar
                </button>
              </div>
              <textarea
                id="emv"
                className="field min-h-28 resize-y font-mono text-[13px] leading-relaxed"
                placeholder="Cole aqui o BR Code gerado pelo seu banco (Nubank, Inter, Itaú…)"
                value={emv}
                onChange={(event) => setEmv(event.target.value)}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
              />
              {inspecting ? (
                <p className="flex items-center gap-2 text-xs font-medium text-slate-500">
                  <Icon name="spinner" size={13} className="animate-spin" />
                  Validando código…
                </p>
              ) : inspection ? (
                <div
                  className={`rounded-xl border px-3 py-2.5 text-xs ${
                    inspection.valid
                      ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                      : "border-rose-200 bg-rose-50 text-rose-700"
                  }`}
                >
                  <p className="flex items-center gap-1.5 font-bold">
                    <Icon name={inspection.valid ? "check" : "alert"} size={14} />
                    {inspection.valid ? "Código Pix válido" : inspection.errors[0] ?? "Código inválido"}
                  </p>
                  <p className="mt-1 leading-relaxed">
                    Valor detectado:{" "}
                    <strong className="font-extrabold">
                      {inspection.amount ? formatBrl(inspection.amount) : "não localizado no código"}
                    </strong>
                    {inspection.amount ? "" : " — o checkout mostrará apenas o código."}
                  </p>
                  <p className="mt-1 break-all font-mono text-[10px] opacity-70">{summarizePixEmv(emv)}</p>
                </div>
              ) : emv.trim().length > 0 ? (
                <p className="text-xs text-slate-400">A validação aparece automaticamente conforme você cola.</p>
              ) : null}
              <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-500">
                <Icon name="shield" size={12} className="mt-0.5 shrink-0" />
                Nada de dados do recebedor aparece para o cliente. Links de copia e cola não têm prazo de validade.
              </p>
            </div>
          ) : null}

          {tab === "api" ? (
            <div className="space-y-3">
              {gateways.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-4 text-center">
                  <p className="text-sm font-semibold text-slate-700">Nenhuma API conectada</p>
                  <p className="mt-1 text-xs text-slate-500">
                    Conecte Asaas, Mercado Pago, BSPay ou PixUp com as suas chaves para gerar cobranças com
                    status de pagamento.
                  </p>
                  <Link href="/integracoes" className="btn btn-primary mt-3 !py-2 !text-xs">
                    <Icon name="plug" size={14} />
                    Ir para Integrações
                  </Link>
                </div>
              ) : (
                <div>
                  <p className="mb-1.5 text-sm font-semibold text-slate-700">API conectada</p>
                  <div className="flex flex-wrap gap-1.5">
                    {gateways.map((gateway) => (
                      <button
                        key={gateway.provider}
                        type="button"
                        onClick={() => setProvider(gateway.provider)}
                        className={`chip ${provider === gateway.provider ? "chip-active" : ""}`}
                      >
                        <Icon name="zap" size={12} />
                        {gateway.name}
                        {gateway.sandbox ? <span className="text-[9px] opacity-70">sandbox</span> : null}
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-500">
                    <Icon name="info" size={12} className="mt-0.5 shrink-0" />
                    Cobranças via API têm status de pagamento (aguardando / pago), atualizado por webhook e
                    consulta automática.
                  </p>
                </div>
              )}
            </div>
          ) : null}

          <div>
            <label htmlFor="amount" className="mb-1.5 block text-sm font-semibold text-slate-700">
              Valor {tab === "copy" ? <span className="font-normal text-slate-400">(extraído do código)</span> : null}
            </label>
            <div className="relative">
              <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                R$
              </span>
              <input
                id="amount"
                className="field pl-10 pr-10"
                placeholder="0,00"
                inputMode="decimal"
                value={amount}
                disabled={tab === "copy"}
                onChange={(event) => setAmount(event.target.value)}
              />
              {amount ? (
                <button
                  type="button"
                  onClick={() => setAmount("")}
                  aria-label="Limpar valor"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                >
                  <Icon name="x" size={15} />
                </button>
              ) : null}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {amountChips.map((chip) => {
                const numeric = normalizeAmountInput(chip);
                const isSaved = presets.amounts.some((saved) => Number(saved) === Number(chip));
                const active = parsedAmount !== null && Number(chip) === parsedAmount;
                return (
                  <span key={chip} className={`chip !py-1 ${active ? "chip-active" : ""}`}>
                    <button type="button" onClick={() => setAmount(numeric ? numeric.toFixed(2) : chip)}>
                      {formatBrl(numeric ?? 0).replace(/\s/g, " ")}
                    </button>
                    {isSaved ? (
                      <button
                        type="button"
                        aria-label="Remover valor salvo"
                        onClick={() => void updatePresets("amount", "remove", chip)}
                        className={active ? "opacity-80" : "text-slate-400 hover:text-rose-500"}
                      >
                        <Icon name="x" size={11} />
                      </button>
                    ) : null}
                  </span>
                );
              })}
              <button
                type="button"
                disabled={!parsedAmount || presets.amounts.length >= 3}
                onClick={() => void updatePresets("amount", "add", String(parsedAmount ?? ""))}
                className="chip !border-dashed !py-1 disabled:opacity-40"
                title="Salvar valor"
              >
                <Icon name="star" size={11} />
                Salvar
              </button>
            </div>
          </div>

          {tab === "key" ? (
            <div className="rounded-xl border border-slate-200 bg-white">
              <button
                type="button"
                onClick={() => setAdvanced((value) => !value)}
                className="flex w-full items-center justify-between gap-2 px-3.5 py-3 text-left"
                aria-expanded={advanced}
              >
                <span className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                  <Icon name="sparkles" size={15} className="text-[var(--brand-dark)]" />
                  Opções avançadas
                </span>
                <Icon
                  name="chevronDown"
                  size={16}
                  className={`text-slate-400 transition-transform ${advanced ? "rotate-180" : ""}`}
                />
              </button>
              {advanced ? (
                <div className="fade-up space-y-3 border-t border-slate-100 p-3.5">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label htmlFor="recipient-name" className="mb-1 block text-xs font-semibold text-slate-600">
                        Nome do recebedor
                      </label>
                      <input
                        id="recipient-name"
                        className="field !py-2.5 !text-sm"
                        placeholder="Só no EMV"
                        value={recipientName}
                        maxLength={25}
                        onChange={(event) => setRecipientName(event.target.value)}
                      />
                    </div>
                    <div>
                      <label htmlFor="recipient-city" className="mb-1 block text-xs font-semibold text-slate-600">
                        Cidade
                      </label>
                      <input
                        id="recipient-city"
                        className="field !py-2.5 !text-sm"
                        placeholder="Só no EMV"
                        value={recipientCity}
                        maxLength={15}
                        onChange={(event) => setRecipientCity(event.target.value)}
                      />
                    </div>
                  </div>
                  <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-500">
                    <Icon name="lock" size={12} className="mt-0.5 shrink-0" />
                    Nome e cidade são usados apenas no código EMV e nunca aparecem na tela do cliente.
                  </p>
                  <div>
                    <label htmlFor="validity" className="mb-1 block text-xs font-semibold text-slate-600">
                      Tempo de validade do link
                    </label>
                    <div className="grid grid-cols-[1fr_auto] gap-2">
                      <input
                        id="validity"
                        className="field !py-2.5 !text-sm"
                        placeholder="Sem prazo"
                        inputMode="numeric"
                        value={validityValue}
                        onChange={(event) => setValidityValue(event.target.value.replace(/[^\d]/g, ""))}
                      />
                      <select
                        className="field !w-auto !py-2.5 !text-sm"
                        value={validityUnit}
                        onChange={(event) => setValidityUnit(event.target.value as "minutes" | "hours")}
                      >
                        <option value="minutes">minutos</option>
                        <option value="hours">horas</option>
                      </select>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-500">
                      Deixe vazio para não expirar. Não se aplica a copia e cola.
                    </p>
                  </div>
                  <div>
                    <label htmlFor="description" className="mb-1 block text-xs font-semibold text-slate-600">
                      Descrição opcional
                    </label>
                    <input
                      id="description"
                      className="field !py-2.5 !text-sm"
                      placeholder="Ex.: pedido 1234"
                      value={description}
                      maxLength={140}
                      onChange={(event) => setDescription(event.target.value)}
                    />
                  </div>
                </div>
              ) : null}
            </div>
          ) : tab === "api" ? (
            <div>
              <label htmlFor="api-description" className="mb-1.5 block text-sm font-semibold text-slate-700">
                Descrição <span className="font-normal text-slate-400">(opcional)</span>
              </label>
              <input
                id="api-description"
                className="field"
                placeholder="Ex.: pedido 1234"
                value={description}
                maxLength={120}
                onChange={(event) => setDescription(event.target.value)}
              />
            </div>
          ) : null}

          {error ? (
            <div className="fade-up flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2.5 text-sm text-rose-700">
              <Icon name="alert" size={15} className="mt-0.5 shrink-0" />
              <span className="leading-snug">{error}</span>
            </div>
          ) : null}
          {notice ? (
            <div className="fade-up flex items-center gap-2 rounded-xl border border-[var(--brand-ring)] bg-[var(--brand-soft-2)] px-3 py-2 text-xs font-semibold text-[var(--brand-dark)]">
              <Icon name="check" size={13} />
              {notice}
            </div>
          ) : null}

          <button
            type="button"
            onClick={generate}
            disabled={busy || (tab === "api" && gateways.length === 0)}
            className="btn btn-primary w-full !py-3.5 !text-[15px]"
          >
            {busy ? (
              <>
                <Icon name="spinner" size={17} className="animate-spin" />
                Gerando…
              </>
            ) : (
              <>
                <Icon name="qr" size={17} />
                Gerar link de pagamento
              </>
            )}
          </button>
        </div>
      </div>

      <section className="fade-up card overflow-hidden">
        <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-4 py-3">
          <h2 className="flex items-center gap-2 text-sm font-bold text-slate-800">
            <Icon name="history" size={16} className="text-[var(--brand-dark)]" />
            Histórico
            <span className="badge bg-slate-100 text-slate-500">{links.length}</span>
          </h2>
          <span className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">privado</span>
        </div>
        {links.length === 0 ? (
          <div className="px-4 py-8 text-center">
            <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-[var(--brand-soft)] text-[var(--brand-dark)]">
              <Icon name="link" size={18} />
            </span>
            <p className="mt-2 text-sm font-semibold text-slate-700">Nenhum link gerado ainda</p>
            <p className="mt-0.5 text-xs text-slate-500">Seus links aparecem aqui, somente para você.</p>
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {links.map((link) => (
              <li key={link.id} className="flex items-center gap-2.5 px-3.5 py-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--brand-soft)] text-[var(--brand-dark)]">
                  <Icon name={link.kind === "api" ? "zap" : link.kind === "copy" ? "code" : "key"} size={15} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="truncate text-sm font-bold text-slate-900">
                      {link.amount ? formatBrl(link.amount) : "Valor livre"}
                    </p>
                    {link.kind === "api" ? (
                      <span
                        className={`badge ${
                          link.payStatus === "paid"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-amber-100 text-amber-700"
                        }`}
                      >
                        {link.payStatus === "paid" ? "Pago" : "Aguardando"}
                      </span>
                    ) : null}
                    {link.expired ? (
                      <span className="badge bg-rose-100 text-rose-700">Expirado</span>
                    ) : null}
                  </div>
                  <p className="truncate text-[11px] text-slate-500">
                    {link.keyMasked} · /p/{link.id} · {formatDateTime(link.createdAt)}
                  </p>
                </div>
                {pendingDelete === link.id ? (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => void removeLink(link.id)}
                      aria-label="Confirmar exclusão"
                      className="icon-btn !border-rose-200 !text-rose-600"
                    >
                      <Icon name="check" size={15} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDelete(null)}
                      aria-label="Cancelar"
                      className="icon-btn"
                    >
                      <Icon name="x" size={15} />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1">
                    {link.kind === "api" && link.payStatus !== "paid" ? (
                      <button
                        type="button"
                        onClick={() => void refreshStatus(link.id)}
                        aria-label="Atualizar status"
                        className="icon-btn"
                      >
                        <Icon name="refresh" size={14} />
                      </button>
                    ) : null}
                    <button
                      type="button"
                      onClick={() => void handleCopy(shortUrl(link.id), link.id)}
                      aria-label="Copiar link"
                      className="icon-btn"
                    >
                      <Icon name={copied === link.id ? "check" : "copy"} size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => reuse(link)}
                      aria-label="Recarregar no gerador"
                      className="icon-btn"
                    >
                      <Icon name="history" size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDelete(link.id)}
                      aria-label="Excluir link"
                      className="icon-btn !text-rose-500"
                    >
                      <Icon name="trash" size={14} />
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
