"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";

export function LogoutButton({
  className = "btn btn-ghost w-full",
  label = "Sair da conta",
}: {
  className?: string;
  label?: string;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  return (
    <button
      type="button"
      className={className}
      disabled={loading}
      onClick={async () => {
        setLoading(true);
        try {
          await fetch("/api/auth/logout", { method: "POST" });
        } catch {
          /* ignora */
        }
        router.replace("/login");
        router.refresh();
      }}
    >
      {loading ? <Icon name="spinner" size={16} className="animate-spin" /> : <Icon name="logout" size={16} />}
      {loading ? "Saindo…" : label}
    </button>
  );
}
