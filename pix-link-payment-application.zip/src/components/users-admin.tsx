"use client";

import { useState } from "react";
import { Icon } from "@/components/icons";
import { copyToClipboard, formatDateTime } from "@/lib/client";

type AdminUser = {
  id: string;
  name: string;
  username: string;
  passwordPlain: string;
  role: string;
  accessUntil: string | null;
  createdAt: string;
};

type EditState = { id: string; name: string; username: string; password: string; days: string };

export function UsersAdmin({ initialUsers }: { initialUsers: AdminUser[] }) {
  const [list, setList] = useState<AdminUser[]>(initialUsers);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [days, setDays] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<EditState | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  async function refresh() {
    const response = await fetch("/api/users", { cache: "no-store" });
    const data = (await response.json().catch(() => ({}))) as { users?: AdminUser[] };
    if (Array.isArray(data.users)) setList(data.users);
  }

  function flash(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(null), 2800);
  }

  async function create() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, username, password, days: days === "" ? null : Number(days) }),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Não foi possível criar o usuário.");
        return;
      }
      setName("");
      setUsername("");
      setPassword("");
      setDays("");
      setShowCreate(false);
      await refresh();
      flash("Usuário criado com sucesso.");
    } catch {
      setError("Falha de conexão.");
    } finally {
      setBusy(false);
    }
  }

  async function saveEdit() {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(`/api/users/${editing.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: editing.name,
          username: editing.username,
          password: editing.password || undefined,
          days: editing.days === "" ? null : Number(editing.days),
        }),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Não foi possível salvar.");
        return;
      }
      setEditing(null);
      await refresh();
      flash("Usuário atualizado.");
    } catch {
      setError("Falha de conexão.");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(`/api/users/${id}`, { method: "DELETE" });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Não foi possível excluir.");
        return;
      }
      setConfirmDelete(null);
      await refresh();
      flash("Usuário excluído.");
    } catch {
      setError("Falha de conexão.");
    } finally {
      setBusy(false);
    }
  }

  async function copyCredentials(user: AdminUser) {
    await copyToClipboard(`usuário: ${user.username} | senha: ${user.passwordPlain}`);
    setCopied(user.id);
    window.setTimeout(() => setCopied((value) => (value === user.id ? null : value)), 1800);
  }

  return (
    <div className="space-y-3">
      {notice ? (
        <div className="fade-up flex items-center gap-2 rounded-xl border border-[var(--brand-ring)] bg-[var(--brand-soft-2)] px-3 py-2.5 text-sm font-semibold text-[var(--brand-dark)]">
          <Icon name="check" size={15} />
          {notice}
        </div>
      ) : null}
      {error ? (
        <div className="fade-up flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2.5 text-sm text-rose-700">
          <Icon name="alert" size={15} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      ) : null}

      <div className="fade-up card overflow-hidden">
        <button
          type="button"
          onClick={() => setShowCreate((value) => !value)}
          className="flex w-full items-center justify-between gap-2 px-4 py-3.5 text-left"
          aria-expanded={showCreate}
        >
          <span className="flex items-center gap-2 text-sm font-bold text-slate-800">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--brand-soft)] text-[var(--brand-dark)]">
              <Icon name="plus" size={16} />
            </span>
            Criar usuário cliente
          </span>
          <Icon
            name="chevronDown"
            size={16}
            className={`text-slate-400 transition-transform ${showCreate ? "rotate-180" : ""}`}
          />
        </button>
        {showCreate ? (
          <div className="fade-up space-y-3 border-t border-slate-100 p-4">
            <div>
              <label htmlFor="new-name" className="mb-1 block text-xs font-semibold text-slate-600">
                Nome
              </label>
              <input
                id="new-name"
                className="field"
                placeholder="Nome do operador"
                value={name}
                onChange={(event) => setName(event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="new-username" className="mb-1 block text-xs font-semibold text-slate-600">
                Usuário
              </label>
              <input
                id="new-username"
                className="field"
                placeholder="usuário de acesso"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={username}
                onChange={(event) => setUsername(event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="new-password" className="mb-1 block text-xs font-semibold text-slate-600">
                Senha
              </label>
              <input
                id="new-password"
                className="field"
                placeholder="senha de acesso"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="new-days" className="mb-1 block text-xs font-semibold text-slate-600">
                Dias de acesso
              </label>
              <input
                id="new-days"
                className="field"
                placeholder="Vazio = sem prazo"
                inputMode="numeric"
                value={days}
                onChange={(event) => setDays(event.target.value.replace(/[^\d]/g, ""))}
              />
              <p className="mt-1 text-[11px] text-slate-500">
                Deixe vazio para acesso sem prazo. Com número, o acesso vale por N dias a partir de agora.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={create} disabled={busy} className="btn btn-primary !py-2.5 !text-sm">
                {busy ? <Icon name="spinner" size={15} className="animate-spin" /> : <Icon name="check" size={15} />}
                Criar usuário
              </button>
              <button type="button" onClick={() => setShowCreate(false)} className="btn btn-ghost !py-2.5 !text-sm">
                Cancelar
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="fade-up card overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
          <h2 className="flex items-center gap-2 text-sm font-bold text-slate-800">
            <Icon name="users" size={16} className="text-[var(--brand-dark)]" />
            Contas
            <span className="badge bg-slate-100 text-slate-500">{list.length}</span>
          </h2>
          <span className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">master</span>
        </div>
        <ul className="divide-y divide-slate-100">
          {list.map((user) => {
            const expired = user.accessUntil ? new Date(user.accessUntil).getTime() <= Date.now() : false;
            const daysLeft = user.accessUntil
              ? Math.max(0, Math.ceil((new Date(user.accessUntil).getTime() - Date.now()) / 86_400_000))
              : null;
            const isMaster = user.role === "master";
            const isEditing = editing?.id === user.id;
            return (
              <li key={user.id} className="px-3.5 py-3">
                {isEditing && editing ? (
                  <div className="fade-up space-y-2.5">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        className="field !py-2 !text-sm"
                        value={editing.name}
                        onChange={(event) => setEditing({ ...editing, name: event.target.value })}
                        placeholder="Nome"
                      />
                      <input
                        className="field !py-2 !text-sm"
                        value={editing.username}
                        onChange={(event) => setEditing({ ...editing, username: event.target.value })}
                        placeholder="Usuário"
                        autoCapitalize="none"
                        spellCheck={false}
                      />
                    </div>
                    <input
                      className="field !py-2 !text-sm"
                      value={editing.password}
                      onChange={(event) => setEditing({ ...editing, password: event.target.value })}
                      placeholder="Nova senha (deixe vazio para manter)"
                      autoCapitalize="none"
                      spellCheck={false}
                    />
                    {!isMaster ? (
                      <div>
                        <input
                          className="field !py-2 !text-sm"
                          value={editing.days}
                          onChange={(event) =>
                            setEditing({ ...editing, days: event.target.value.replace(/[^\d]/g, "") })
                          }
                          placeholder="Dias de acesso (vazio = sem prazo)"
                          inputMode="numeric"
                        />
                        <p className="mt-1 text-[10px] text-slate-400">
                          Conta a partir de agora. Vazio remove o prazo.
                        </p>
                      </div>
                    ) : null}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={saveEdit}
                        disabled={busy}
                        className="btn btn-primary !py-2 !text-xs"
                      >
                        <Icon name="check" size={14} />
                        Salvar
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditing(null)}
                        className="btn btn-ghost !py-2 !text-xs"
                      >
                        <Icon name="x" size={14} />
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-2.5">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--brand-soft)] text-xs font-extrabold text-[var(--brand-dark)]">
                      {user.name
                        .split(/\s+/)
                        .filter(Boolean)
                        .slice(0, 2)
                        .map((part) => part[0]?.toUpperCase())
                        .join("")}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <p className="truncate text-sm font-bold text-slate-900">{user.name}</p>
                        <span
                          className={`badge ${
                            isMaster ? "bg-[var(--brand-soft)] text-[var(--brand-dark)]" : "bg-slate-100 text-slate-500"
                          }`}
                        >
                          {isMaster ? "Master" : "Cliente"}
                        </span>
                        {!isMaster ? (
                          <span
                            className={`badge ${expired ? "bg-rose-100 text-rose-700" : "bg-emerald-100 text-emerald-700"}`}
                          >
                            {expired ? "Expirado" : user.accessUntil ? `${daysLeft}d` : "Sem prazo"}
                          </span>
                        ) : null}
                      </div>
                      <p className="truncate text-[11px] text-slate-500">
                        @{user.username} · senha:{" "}
                        <span className="font-mono text-[11px] text-slate-700">{user.passwordPlain}</span>
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {isMaster
                          ? "Acesso vitalício"
                          : user.accessUntil
                            ? `Expira em ${formatDateTime(user.accessUntil)}`
                            : "Sem data de expiração"}
                        {" · criado em "}
                        {formatDateTime(user.createdAt)}
                      </p>
                    </div>
                    {confirmDelete === user.id ? (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => void remove(user.id)}
                          disabled={busy}
                          aria-label="Confirmar exclusão"
                          className="icon-btn !border-rose-200 !text-rose-600"
                        >
                          <Icon name="check" size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDelete(null)}
                          aria-label="Cancelar"
                          className="icon-btn"
                        >
                          <Icon name="x" size={15} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => void copyCredentials(user)}
                          aria-label="Copiar credenciais"
                          className="icon-btn"
                        >
                          <Icon name={copied === user.id ? "check" : "copy"} size={14} />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setEditing({
                              id: user.id,
                              name: user.name,
                              username: user.username,
                              password: "",
                              days:
                                user.accessUntil && !isMaster
                                  ? String(
                                      Math.max(
                                        1,
                                        Math.ceil(
                                          (new Date(user.accessUntil).getTime() - Date.now()) / 86_400_000,
                                        ),
                                      ),
                                    )
                                  : "",
                            })
                          }
                          aria-label="Editar usuário"
                          className="icon-btn"
                        >
                          <Icon name="palette" size={14} />
                        </button>
                        {!isMaster ? (
                          <button
                            type="button"
                            onClick={() => setConfirmDelete(user.id)}
                            aria-label="Excluir usuário"
                            className="icon-btn !text-rose-500"
                          >
                            <Icon name="trash" size={14} />
                          </button>
                        ) : null}
                      </div>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </div>

      <div className="card flex items-start gap-2.5 p-4">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[var(--brand-soft)] text-[var(--brand-dark)]">
          <Icon name="lock" size={15} />
        </span>
        <p className="text-[11px] leading-relaxed text-slate-500">
          As senhas ficam visíveis apenas para o master, para agilizar o suporte. Clientes expirados ou não
          liberados não acessam o gerador, e cada conta enxerga somente os próprios links, chaves, histórico e
          integrações.
        </p>
      </div>
    </div>
  );
}
